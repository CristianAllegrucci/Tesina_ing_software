package View;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Controller.CalcolaMezziDisponibili;
import Controller.CalcolaNasciteVitelliSuPeriodo;
import Controller.CalcolaPagamentoSuPeriodo;
import Controller.CalcolaSpesaSuPeriodo;
import Controller.FiltraNasciteVitelliUltimoAnno;
import Controller.FiltraPagamentiUltimaSettimana;
import Controller.FiltroTemporale;
import Controller.OperazioneSuPeriodoTemporale;
import Controller.TassoNatalita;
import Model.Azienda;
import Model.Bovino;
import Model.Dipendente;
import Model.Mezzo;
import Model.Pagamento;
import Model.Spesa;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class GestoreAzienda {

	Azienda azienda = Azienda.getIstanza();

	public GestoreAzienda(Azienda azienda) {
		this.azienda = azienda;
	}

	// gestione dipendenti
	public void aggiungiDidendente(String nome, String cognome, LocalDate dataDiNascita) {
		azienda.aggiungiDipendente(nome, cognome, dataDiNascita);
		;
	}

	public void rimuoviDidendente(Dipendente dipendente) {
		if (azienda.getListaDipendente().size() == 0) {
			System.out.println("Lista dipendenti vuota, " + "impossibile rimuovere");
		} else {
			azienda.rimuoviDipendente(dipendente);
		}
	}

	// gestione bovini
	public void aggiungiBovino(String matricola,double peso, String razza,LocalDate dataDiNascita,char sesso)
			throws ClassNotFoundException, SQLException , NullPointerException{
		azienda.aggiungiBovino(matricola, peso, razza, dataDiNascita, sesso);
	
		String valore = "'"+matricola.toString()+"',"+peso+",'"+razza.toString()+"','"+ dataDiNascita.toString()+"','"+ sesso+"'"; //valore di esempio
		int esito; //esito aggiornamento

		//carica il file di classe del driver per il ponte jdbc
		Class.forName("com.mysql.jdbc.Driver");

		//crea la connessione con l'origine dati
		String jdbcUrl = "jdbc:mysql://localhost/DataBaseBovini?user=root&password=Password93.&useUnicode=true&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false";
		Connection conn = DriverManager.getConnection(jdbcUrl);
		//crea lo statement
		Statement st = (Statement) conn.createStatement();

		//esegue l'aggiornameto o l'inserimento
		esito = st.executeUpdate("INSERT INTO Bovini values ("+valore+");");
		

		//se esito è uguale a 1 tutto è andato bene
		if (esito == 1)
		System.out.println("inserimento eseguito correttamente");
		else
			System.out.println("inserimento non eseguito");


		//rs.close();
		conn.close();
	}

	// rimozione dovuta a vendita/dispersione/morte
	public void rimuoviBovino(Bovino bovino) {
		if (azienda.getListaBovini().size() == 0) {
			System.out.println("Lista bovini vuota, " + "impossibile rimuovere");
		} else {
			azienda.rimuoviBovino(bovino);
		}
	}

	// Spesa
	public void aggiungiFattura(Spesa spesa) {
		if (azienda.getListaSpese().contains(spesa)) {
			System.out.println("La lista contiene già questo elemento");
		} else {
			azienda.getListaSpese().add(spesa);
		}
	}

	/*
	 * metodo per richiamare lo strategy sulle operazioni di pagamento. sul main mi
	 * preoccupero di passare il filtro e il tipo di costo da calcolare VEDISOTTO
	 */
	/*
	 * public double
	 * calcolaPagamentoSuPeriodo(OperazioneSuPagamentoSuPeriodoTemporale
	 * op,List<Pagamento> listaPagamenti) { return
	 * op.calcolaSuPeriodo(listaPagamenti); }
	 */

	public double calcolaSpesaUltimaSettimana(List<Pagamento> listaPagamenti) {
		FiltroTemporale<Pagamento> filtro = new FiltraPagamentiUltimaSettimana();
		CalcolaPagamentoSuPeriodo c = new CalcolaSpesaSuPeriodo(filtro);
		double risultato = c.calcolaSuPeriodo(listaPagamenti);
		return risultato;
	}

	public double calcolaNasciteVitelliUltimoAnno() {
		FiltroTemporale<Bovino> filtro = new FiltraNasciteVitelliUltimoAnno();
		CalcolaNasciteVitelliSuPeriodo c = new CalcolaNasciteVitelliSuPeriodo(filtro);
		double risultato = c.calcolaSuPeriodo(azienda.getListaBovini());
		return risultato;
	}

	// calcola mezzi attualmente disponibili
	public List<Mezzo> mezziAttualmenteDisponibili() {
		CalcolaMezziDisponibili calc = new CalcolaMezziDisponibili();
		return calc.calcolaMezziDisponibili(azienda.getListaMezzi());
	}
	// calcola tasso di natalita

	public double tassoDiNatalita() {
		FiltroTemporale<Bovino> filtro = new FiltraNasciteVitelliUltimoAnno();
		double nuoviNati = new CalcolaNasciteVitelliSuPeriodo(filtro).calcolaSuPeriodo(azienda.getListaBovini());
		double popolazioneCorrente = azienda.getListaBovini().size();
		double popolazioneAdUnAnnoFa = azienda.getListaBovini().size() - nuoviNati;

		return new TassoNatalita(nuoviNati, popolazioneCorrente, popolazioneAdUnAnnoFa).calcola();

	}
}
