package Model;
import java.util.ArrayList;
import java.util.List;

// versione 2 di stalla.java che estende la classe gruppi
// evito duplicazione del codice

public class Stalla extends Gruppo{
	private List<Edificio> listaEdificiPerStalla=
			new ArrayList<Edificio>();
	
	public Stalla(String codice, List<Bovino> listaBovini
			, Edificio edificio) {
		super(codice, listaBovini);
		aggiungiEdificio(edificio);
	}
	public void aggiungiEdificio(Edificio edificio) {
		listaEdificiPerStalla.add(edificio);
	}
	
	
	// da creare classe in cui definire gli stabili 
	//che possono essere utilizzati
	// e classificarli in base alla capienza e alla dimensione

	// si pu� mettere quanto segue con un interfaccia 
}
