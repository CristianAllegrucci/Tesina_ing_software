package Model;
import java.time.LocalDate;

public class Mezzo {
	
	private String marca;
	private String modello;
	private String targa;	// nel formato LLnnnLL es. AA000AA - va inserito un controllo sulla validit�
	private double consumo;	
	private LocalDate dataImmatricolazione;
	private boolean disponibile;

	public Mezzo(String marca, String modello, String targa, double consumo, LocalDate immatricolazione,
			LocalDate prossimaRevisione, boolean disponibile) {
		// super();
		this.marca = marca;
		this.modello = modello;
		this.targa = targa;
		this.consumo = consumo;
		this.dataImmatricolazione = immatricolazione;
		this.disponibile=disponibile;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getTarga() {
		return targa;
	}

	public void setTarga(String targa) {
		this.targa = targa;
	}

	public double getConsumo() {
		return consumo;
	}

	public void setConsumo(double consumo) {
		this.consumo = consumo;
	}

	public LocalDate getImmatricolazione() {
		return dataImmatricolazione;
	}

	public void setImmatricolazione(LocalDate immatricolazione) {
		this.dataImmatricolazione = immatricolazione;
	}

	public boolean isDisponibile() {
		return true;
	}

	public void setDisponibile(boolean disponibile) {
		this.disponibile = disponibile;
	}
	
}