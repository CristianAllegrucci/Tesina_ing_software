package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import Model.Azienda;
import Model.Bovino;
import View.GestoreAzienda;

public class DataBaseBovini implements IDataBase {
	private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_CONNECTION = "jdbc:mysql://localhost/DataBaseBovini?user=root&password=Password93.&useUnicode=true&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "Password93.";
	private Connection connessione;

	@Override
	public Connection connessioneDB() {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			this.connessione = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return connessione;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return connessione;
	}

	@Override
	public void aggiornaDB(String query) {
		// Connection connection = connessioneDB();
		Statement stmt = null;
		try {
			this.connessione.setAutoCommit(false);
			stmt = this.connessione.createStatement();
			stmt.execute(query);
			stmt.close();
			this.connessione.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
			System.out.println("My Error: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void chiudiConnessione() {
		try {
			this.connessione.close();
		} catch (SQLException e) {
			System.out.println("Errore durante la chiusura del db: " + e.getLocalizedMessage());
		}
	}

	@Override
	public Statement creaDichiarazione() {
		Statement stmt = null;
		try {
			this.connessione.setAutoCommit(false);
			stmt = this.connessione.createStatement();
			this.connessione.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stmt;
	}
//Lettura DataBase-Stampa il db sulla console
	public  void leggiDB() throws SQLException {
		String jdbcUrl = this.DB_CONNECTION;
		Connection con = this.connessioneDB();
		Statement stmt = this.creaDichiarazione();
		String query = "SELECT * FROM Bovini ;";
		ResultSet rs = this.creaDichiarazione().executeQuery(query);
		try {
			while (rs.next()) {
				int numColumns = rs.getMetaData().getColumnCount();
				for (int i = 1; i <= numColumns; i++) {
					System.out.println("COLUMN " + i + " = " + rs.getObject(i));
				}
			}
		} finally {
			try {
				rs.close();
			} catch (Throwable ignore) {}
			finally {
				try {
					stmt.close();
				} catch (Throwable ignore) { }

				finally {
					try {
						con.close();
					} catch (Throwable ignore) {}
				}
				System.out.println("DB Connesso!");
				con.close();

			}
		}
	}
//Cambiando i valori potremmocreare le varie tabelle del nostro db
	public void creaTabelle() {
    	String prefisso = "CREATE TABLE IF NOT EXISTS ";
    	this.aggiornaDB(prefisso+"`DataBaseBovini`.`BoviniDue` (\r\n" + 
    			"  `matricola` VARCHAR(14) NOT NULL,\r\n" + 
    			"  `peso` DOUBLE NOT NULL,\r\n" + 
    			"  `razza` VARCHAR(20) NULL,\r\n" + 
    			"  `dataDiNascita` DATE NOT NULL,\r\n" + 
    			"  `sesso` ENUM('M', 'F') NOT NULL,\r\n" + 
    			"  PRIMARY KEY (`matricola`))");
	}
 
  public void cancellaTabelle() {
    	this.aggiornaDB("DROP TABLE DataBaseBovini.BoviniDue");
    }
  
  public void inserisciBovino(Bovino bovino) {
  	String query = "INSERT INTO Bovini VALUES ('"
  						+ bovino.getMatricola() +"','"
							+ bovino.getPeso() + "','"
							+ bovino.getRazza() + "','"
							+ bovino.getDataDiNascita() + "','"
							+ bovino.getSesso() + "')";
  	this.aggiornaDB(query);
  }

}
