package Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Model.Pagamento;

public class FiltraPagamenti extends FiltroPeriodoGenerico
implements FiltroTemporale<Pagamento>{

	public FiltraPagamenti(LocalDate dataInizio, LocalDate dataFine) {
		super(dataInizio, dataFine);
	}

	@Override
	public List<Pagamento> filtraTemporalmente(List<Pagamento> listaPagamenti) {
		List<Pagamento> listaFiltrata = new ArrayList<Pagamento>();

		for (Pagamento p: listaPagamenti)
		{
			if ( p.getDataFattura().isAfter(dataInizio) && p.getDataFattura().isBefore(dataFine))
			{
				listaFiltrata.add(p);
			}
		}
		return listaFiltrata;
	}

}
