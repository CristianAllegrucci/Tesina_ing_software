package Controller;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

import Model.Pagamento;

public class FiltraPagamentiUltimaSettimana extends FiltraPagamenti{

	public FiltraPagamentiUltimaSettimana() {
		super(LocalDate.now().plusDays(-7), LocalDate.now());
	}

}
