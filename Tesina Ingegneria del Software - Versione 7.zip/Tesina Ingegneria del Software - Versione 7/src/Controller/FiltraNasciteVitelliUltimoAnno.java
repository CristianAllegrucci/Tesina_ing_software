package Controller;

import java.time.LocalDate;

import Model.Bovino;
import Model.Pagamento;

public class FiltraNasciteVitelliUltimoAnno extends FiltraNasciteVitelli
implements FiltroTemporale<Bovino>{

	public FiltraNasciteVitelliUltimoAnno() {
		super(LocalDate.now(), LocalDate.now().minusYears(1));
	}

}
