package Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*Ho spostato tutte le funzioni in gestore azienda in modo da lasciare azienda
 * piu pulita*/
public class Azienda {
	// Singleton
	private static Azienda istanza;

	private Azienda() {
	}

	public static Azienda getIstanza() {
		if (istanza == null)
			istanza = new Azienda();
		return istanza;
	}

	// Dati dell'azienda
	private String nome;
	private String citta;
	private String indirizzo;
	private String telefono; // no int perche potrebbe ignorare eventuali 0 iniziali 0039-075.... -> 39-....
	// ho messo int perche in p.iva ci sono tutti interi senza lettere
	private String partitaIva;
	private List<Spesa> listaSpese = new ArrayList<Spesa>();
	private List<Guadagno> listaGuadagni = new ArrayList<Guadagno>();

	// Risorse
	private List<Dipendente> listaDipendente= new ArrayList<Dipendente>();
	private List<Bovino> listaBovini= new ArrayList<Bovino>();
	private List<Mezzo>listaMezzi= new ArrayList<Mezzo>();
	// Costruttore

	public Azienda(String nome, String citta, String indirizzo, String telefono, String partitaIva,
			List<Spesa> listaSpese, List<Guadagno> listaGuadagni, List<Dipendente> listaDipendente,
			List<Bovino> listaBovini, List<Mezzo>listaMezzi) {
		super();
		this.nome = nome;
		this.citta = citta;
		this.indirizzo = indirizzo;
		this.telefono = telefono;
		this.partitaIva = partitaIva;
		this.listaSpese = listaSpese;
		this.listaGuadagni = listaGuadagni;
		this.listaDipendente = listaDipendente;
		this.listaBovini = listaBovini;
		this.listaMezzi=listaMezzi;
	}

	public List<Mezzo> getListaMezzi() {
		return listaMezzi;
	}

	public void setListaMezzi(List<Mezzo> listaMezzi) {
		this.listaMezzi = listaMezzi;
	}

	public String getNome() {
		return nome;
	}

	public List<Spesa> getListaSpese() {
		return listaSpese;
	}

	public void setListaSpese(List<Spesa> listaSpese) {
		this.listaSpese = listaSpese;
	}

	public List<Guadagno> getListaGuadagni() {
		return listaGuadagni;
	}

	public void setListaGuadagni(List<Guadagno> listaGuadagni) {
		this.listaGuadagni = listaGuadagni;
	}

	public static void setIstanza(Azienda istanza) {
		Azienda.istanza = istanza;
	}

	public List<Dipendente> getListaDipendente() {
		return listaDipendente;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public void setListaDipendente(List<Dipendente> listaDipendente) {
		this.listaDipendente = listaDipendente;
	}

	public List<Bovino> getListaBovini() {
		return listaBovini;
	}

	public void setListaBovini(List<Bovino> listaBovini) {
		this.listaBovini = listaBovini;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public void setIappartenenzandirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public void setPartitaIva(String partitaIva) {
		this.partitaIva = partitaIva;
	}

	public String getCitta() {
		return citta;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public String getTelefono() {
		return telefono;
	}

	public String getPartitaIva() {
		return partitaIva;
	}
// RIMOZIONE DIP/BOVINO
	public void rimuoviBovino(Bovino bovino) {
		if (!listaBovini.contains(bovino)) {
			System.out.println("Errore, bovino non presente");
		} else {
			listaBovini.remove(bovino);
		}

	}

	public void rimuoviDipendente(Dipendente dipendente) {
		if (!listaDipendente.contains(dipendente)) {
			System.out.println("Errore, dipendente non presente");
		} else {
			listaDipendente.remove(dipendente);
		}
	}
//AGGIUNTA DIP/BOVINO
	public void aggiungiDipendente(String nome, String cognome,
			LocalDate dataDiNascita) {
		Dipendente dipendente = new Dipendente(nome, cognome, dataDiNascita);
		if(listaDipendente.contains(dipendente)) {
			System.out.println("Errore, dipendente già presente");
		}else {
		listaDipendente.add(dipendente);
		}
	}

	public void aggiungiBovino(LocalDate dataDiNascita, double peso, 
			String matricola, String razza, String sesso) {
		Bovino bovino = new Bovino(dataDiNascita, peso, matricola, razza, sesso);
		if(listaBovini.contains(bovino)) {
			System.out.println("Errore, bovino già registrato");
		}else {
			listaBovini.add(bovino);
		}
	}
}
