package Model;
import java.util.ArrayList;
import java.util.List;

// classe astratta comune sia a mandria che a stalla

public abstract class Gruppo {

	private String codice;
	private List<Bovino> listaBovini;

	public Gruppo(String codice, List<Bovino> listaBovini) {
		this.codice = codice;
		this.listaBovini = new ArrayList<>(); // oppure arraylist
		// ipotizzio che nel momento in cui creo una mandria/stalla, questa sia vuota
	}

	// stalla e mandria sono oggetti dinamici, i bovini vengono aggiunti e
	// rimossi ripetutamente durante il corso dell'anno

	public String getCodice() {
		return codice;
	}

	public List<Bovino> getListaBovini() {
		return listaBovini;
	}

	public void aggiungiBovino(Bovino bovino) {
		listaBovini.add(bovino);
	}

	public void rimuoviBovino(Bovino bovino) {
		/*
		 * Ricerca del bovino nella lista per mezzo dell'identificativo
		 */
		int index = 0;

		listaBovini.remove(index);
	}

	public int numeroVitelli() {
		int n = 0;

		/*
		 * Calcolo del numero di vitelli a partire dalla lista dei bovini ricercando
		 * quelli con et� inferiore ai 12 mesi e peso inferiore a 250Kg (Wikipedia)
		 */

		return n;
	}

	public int boviniAdulti() {
		// analogamente a sopra, si pu� fare uno strategy e un filtraggio temporale

		return 0;
	}
}
