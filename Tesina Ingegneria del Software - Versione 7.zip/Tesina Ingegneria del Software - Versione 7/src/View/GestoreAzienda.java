package View;

import java.time.LocalDate;
import java.util.List;

import Controller.CalcolaNasciteVitelliSuPeriodo;
import Controller.CalcolaPagamentoSuPeriodo;
import Controller.CalcolaSpesaSuPeriodo;
import Controller.FiltraNasciteVitelliUltimoAnno;
import Controller.FiltraPagamentiUltimaSettimana;
import Controller.FiltroTemporale;
import Controller.OperazioneSuPeriodoTemporale;
import Model.Azienda;
import Model.Bovino;
import Model.Dipendente;
import Model.Pagamento;
import Model.Spesa;

public class GestoreAzienda {

	Azienda azienda = Azienda.getIstanza();

	public GestoreAzienda(Azienda azienda) {
		this.azienda = azienda;
	}

	// gestione dipendenti
	public void aggiungiDidendente(String nome, String cognome,
			LocalDate dataDiNascita) {
			azienda.aggiungiDipendente(nome, cognome, dataDiNascita);;
		}
	

	public void rimuoviDidendente(Dipendente dipendente) {
		if (azienda.getListaDipendente().size() == 0) {
			System.out.println("Lista dipendenti vuota, " + 
		"impossibile rimuovere");
		} else {
			azienda.rimuoviDipendente(dipendente);
		}
	}

	// gestione bovini
	public void aggiungiBovino(LocalDate dataDiNascita, double peso, 
			String matricola, String razza, String sesso) {
			azienda.aggiungiBovino(dataDiNascita, peso, matricola, razza, sesso);;
			}
	//rimozione dovuta a vendita/dispersione/morte
	public void rimuoviBovino(Bovino bovino) {
		if (azienda.getListaBovini().size() == 0) {
			System.out.println("Lista bovini vuota, " + "impossibile rimuovere");
		} else {
				azienda.rimuoviBovino(bovino);
		}
	}

	// Spesa
	public void aggiungiFattura(Spesa spesa) {
		if (azienda.getListaSpese().contains(spesa)) {
			System.out.println("La lista contiene già questo elemento");
		} else {
			azienda.getListaSpese().add(spesa);
		}
	}

	/*
	 * metodo per richiamare lo strategy sulle operazioni di pagamento. sul main mi
	 * preoccupero di passare il filtro e il tipo di costo da calcolare
	 */
	/*public double calcolaPagamentoSuPeriodo(OperazioneSuPagamentoSuPeriodoTemporale op,List<Pagamento> listaPagamenti) {
		return op.calcolaSuPeriodo(listaPagamenti);
	}
	*/
	
	
	public double calcolaSpesaUltimaSettimana(List<Pagamento> listaPagamenti) {
		FiltroTemporale<Pagamento> filtro=new FiltraPagamentiUltimaSettimana();
		CalcolaPagamentoSuPeriodo c=new CalcolaSpesaSuPeriodo(filtro);
		double risultato=c.calcolaSuPeriodo(listaPagamenti);
		return risultato;
	}
	
	public double calcolaNasciteVitelliUltimoAnno(List<Bovino> listaBovini) {
		FiltroTemporale<Bovino> filtro=new FiltraNasciteVitelliUltimoAnno();
		CalcolaNasciteVitelliSuPeriodo c=new CalcolaNasciteVitelliSuPeriodo(filtro) ;
		double risultato=c.calcolaSuPeriodo(listaBovini);
		return risultato;
	}
	
	
}
