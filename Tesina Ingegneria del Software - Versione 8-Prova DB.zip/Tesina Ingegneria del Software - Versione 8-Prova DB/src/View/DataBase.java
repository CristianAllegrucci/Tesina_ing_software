package View;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.time.LocalDate;

import com.mysql.jdbc.Statement;

import Model.Azienda;

public class DataBase {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException ex) {
			System.err.println("Unable to load MySQL Driver");
		}
	}

	static public void main(String[] args) throws Exception {
		
		GestoreAzienda azienda=new GestoreAzienda(Azienda.getIstanza());
		azienda.aggiungiBovino("IT056000054781", 710, "Maremmana", LocalDate.of(2001, 2, 1), 'F');;;
		String jdbcUrl = "jdbc:mysql://localhost/DataBaseBovini?user=root&password=Password93.&useUnicode=true&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false";
		Connection con = DriverManager.getConnection(jdbcUrl);
		Statement stmt = (Statement) con.createStatement();
		String query = "SELECT * FROM Bovini ;";
		ResultSet rs = stmt.executeQuery(query);
		try {
			while (rs.next()) {
				int numColumns = rs.getMetaData().getColumnCount();
				for (int i = 1; i <= numColumns; i++) {
					// Column numbers start at 1.
					// Also there are many methods on the result set to return
					// the column as a particular type. Refer to the Sun documentation
					// for the list of valid conversions.
					System.out.println("COLUMN " + i + " = " + rs.getObject(i));
				}
			}
		} finally {
			try {
				rs.close();
			} catch (Throwable ignore) {
				/*
				 * Propagate the original exception instead of this one that you may want just
				 * logged
				 */ }

			finally {
				try {
					stmt.close();
				} catch (Throwable ignore) {
					/*
					 * Propagate the original exception instead of this one that you may want just
					 * logged
					 */ }

				finally {
					// It's important to close the connection when you are done with it
					try {
						con.close();
					} catch (Throwable ignore) {
						/*
						 * Propagate the original exception instead of this one that you may want just
						 * logged
						 */ }
				}
				System.out.println("Connected!");
				con.close();
				
				
			}
		}
	}
}
