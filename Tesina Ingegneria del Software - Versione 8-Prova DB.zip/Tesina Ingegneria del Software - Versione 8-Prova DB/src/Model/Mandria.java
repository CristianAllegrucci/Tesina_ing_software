package Model;
import java.util.LinkedList;
import java.util.List;

// come per la stalla pu� essere vista come una lista di bovini
// dimensioni ridotte ??

public class Mandria extends Gruppo{

	public Mandria(String codice, List<Bovino> listaBovini) {
		super(codice, listaBovini);
	}

	// private Pascolo pascolo;


	
}
