package Model;
import java.time.LocalDate;
import java.util.List;
//vecchio fatturato
public class Guadagno extends Pagamento{

	public Guadagno(LocalDate dataFattura, double costo) {
		super(dataFattura, costo);
	}

	
	/*public double Ricavo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Vendita")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}*/
}
