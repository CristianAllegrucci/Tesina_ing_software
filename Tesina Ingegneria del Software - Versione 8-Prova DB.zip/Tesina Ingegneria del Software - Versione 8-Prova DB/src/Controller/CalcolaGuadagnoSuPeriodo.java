package Controller;
import Model.Guadagno;
import Model.Pagamento;

public class CalcolaGuadagnoSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaGuadagnoSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaSpesa(Pagamento pagamento) {
		if(pagamento instanceof Guadagno) {
			return false ;
		}	
		return true;
		}

}
