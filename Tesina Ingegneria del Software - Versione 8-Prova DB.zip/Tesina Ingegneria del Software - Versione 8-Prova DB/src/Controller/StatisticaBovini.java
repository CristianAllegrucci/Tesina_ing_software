package Controller;
import java.util.List;

import Model.Bovino;
public interface StatisticaBovini {

	public double calcola();
}
