import java.util.LinkedList;
import java.util.List;

public class Stalla_old {
	
	private String codice; // identificativo della stalla
	
	private List<Bovino> listaBovini;

	public Stalla_old(String codice) {
		super();
		this.codice = codice;
		this.listaBovini = new LinkedList<>(); // oppure arraylist
		
	}
	
	// la stalla � un oggetto dinamico, i bovini vengono aggiunti e rimossi ripetutamente durante 
	// il corso dell'anno
	
	public String getCodice() {
		return codice;
	}

	public void aggiungiBovino(Bovino bovino)
	{
		listaBovini.add(bovino);
	}
	
	public void rimuoviBovino(Bovino bovino)
	{
		/*
		 *  Ricerca del bovino nella lista per mezzo dell'identificativo
		 */
	}
	
	public int numeroVitelli()
	{
		int n=0;
		
		/*	Calcolo del numero di vitelli a partire dalla lista dei bovini
		 *  ricercando quelli con et� inferiore ai 12 mesi e peso inferiore a 250Kg (Wikipedia)
		 */
		
		return n;
	}

	public int boviniAdulti()
	{
		// analogamente a sopra, si pu� fare uno strategy e un filtraggio temporale
		
		return 0;
	}
}
