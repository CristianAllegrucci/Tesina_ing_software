import java.util.LinkedList;
import java.util.List;

public class Azienda {

	// Dati dell'azienda
	private String nome;
	private String citta;
	private String indirizzo;
	private String telefono; // no int perch� potrebbe ignorare eventuali 0 iniziali 0039-075.... -> 39-....
	private String partitaIva;
	private double fatturato;
	private double spese;

	// Risorse
	private List<Dipendente> listaDipendente;
	private List<Bovino> listaBovini;

	// Costruttore
	public Azienda(String nome, String citta, String indirizzo, String telefono, String partitaIva) {
		super();
		this.nome = nome;
		this.citta = citta;
		this.indirizzo = indirizzo;
		this.telefono = telefono;
		this.partitaIva = partitaIva;
		this.listaDipendente= new LinkedList<>();
		this.listaBovini= new LinkedList<>();
	}

	public String getNome() {
		return nome;
	}

	public String getCitta() {
		return citta;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public String getTelefono() {
		return telefono;
	}

	public String getPartitaIva() {
		return partitaIva;
	}

	public void AggiungiDidendente(Dipendente d)
	{
		listaDipendente.add(d);
	}
	public void RimuoviDidendente(Dipendente d)
	{
		if (listaDipendente.size()==0)
		{
			System.out.println("Lista dipendenti vuota, impossibile rimuovere");
		}
		else
		{
			int i=0;
			/*
			 * 
			 * 
			 */
			listaDipendente.remove(i);
		}
	}

	public void AggiungiBovino(Bovino b)
	{
		listaBovini.add(b);
	}
	public void RimuoviBovino(Bovino b)
	{
		if (listaBovini.size()==0)
		{
			System.out.println("Lista bovini vuota, impossibile rimuovere");
		}
		else
		{
			int i=0;
			/*
			 * 
			 * 
			 */
			listaBovini.remove(i);
		}
	}

}
