import java.util.LinkedList;
import java.util.List;

// come per la stalla pu� essere vista come una lista di bovini
// dimensioni ridotte ??

public class Mandria {

	private String codice;
	
	private List boviniMandria;

	public Mandria() {
		//super();
		this.boviniMandria = new LinkedList<>();;
	}
	
	public void aggiungiBovino(Bovino bovino)
	{
		
	}

	// da completare
	
	// probabile classe astratta con stalla
}
