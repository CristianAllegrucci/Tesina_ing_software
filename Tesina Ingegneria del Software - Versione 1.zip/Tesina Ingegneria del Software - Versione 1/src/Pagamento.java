import java.util.Date;

public class Pagamento {

	private Date dataFattura;
	private Date dataPagamento;
	private double prezzoVendita;
	private String tipologia;
	
	public Pagamento(Date dataFattura, Date dataPagamento, double prezzoVendita, String tipologia) {
		super();
		this.tipologia = tipologia;
		this.dataFattura = dataFattura;
		this.dataPagamento = dataPagamento;
		this.prezzoVendita = prezzoVendita;
	}

	public Date getDataFattura() {
		return dataFattura;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public double getPrezzoVendita() {
		return prezzoVendita;
	}
	
	public String getTipologia(){
		return tipologia;
	}
	
}
