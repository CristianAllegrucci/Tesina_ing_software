import java.util.List;

public interface FiltraTipologia {

	public List<Bovino> filtra(Gruppi g);

}
