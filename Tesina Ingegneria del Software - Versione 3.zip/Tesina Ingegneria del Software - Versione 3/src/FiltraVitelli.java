import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class FiltraVitelli implements FiltraTipologia {

	double peso;
	
	public FiltraVitelli(double peso)
	{
		this.peso=peso;
		// posso variare la data aggiungendo al costruttore gli anni entro cui � ancora vitello
	}
	
	@Override
	public List<Bovino> filtra(Gruppi gruppo) {
		List<Bovino> input = gruppo.getListaBovini();
		List<Bovino> output = new LinkedList<>();

		for(Bovino bovino : input)
		{
			// inserisco la data qui perch� la definizione � fissa
			if (bovino.getNascita().isBefore(LocalDate.now().plusYears(-1)) && bovino.getPeso() < peso)
			{
				output.add(bovino);
			}
		}
		return output;
	}

}
