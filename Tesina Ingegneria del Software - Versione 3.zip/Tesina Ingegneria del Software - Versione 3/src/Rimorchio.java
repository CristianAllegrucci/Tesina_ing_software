import java.util.Date;

public class Rimorchio extends Mezzo{
	
	private Mezzo mezzoPrincipale;

	public Rimorchio(String marca, String modello, String targa, double consumo, Date immatricolazione,
			Date prossimaRevisione, Mezzo mezzoPrincipale) 
	{
		
		super(marca, modello, targa, consumo, immatricolazione, prossimaRevisione);
		
		this.mezzoPrincipale = mezzoPrincipale;
		// TODO Auto-generated constructor stub
	}

	public void cambiaPrincipale(Mezzo nuovoPrincipale)
	{
		mezzoPrincipale= nuovoPrincipale;
	}
}
