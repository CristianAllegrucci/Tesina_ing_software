import java.util.Date;

public class Mezzo {
	
	private String marca;
	private String modello;
	
	private String targa;	// nel formato LLnnnLL es. AA000AA - va inserito un controllo sulla validit�
	
	// nel caso di un rimorchio, si hanno due targhe, quella del mezzo principale a cui � collegato
	// e quella del rimorchio stesso. inoltre andrebbe inserito il mezzo principale
	
	// private boolean rimorchio;
	// private Mezzo mezzoPrincipale;
	
	private double consumo;
	
	private Date immatricolazione;
	private Date prossimaRevisione;
	
	// private String note; //eventuali annotazioni da fare sul veicolo ??
	
	public Mezzo(String marca, String modello, String targa, double consumo, Date immatricolazione,
			Date prossimaRevisione) {
		// super();
		this.marca = marca;
		this.modello = modello;
		this.targa = targa;
		this.consumo = consumo;
		this.immatricolazione = immatricolazione;
		this.prossimaRevisione = prossimaRevisione;
	}

	// La data della successiva revisione varia nel momento in cui ne viene effettuata una
	// Il metodo per aggiornarla � quindi necessario
	// I restanti parametri restano fissi
	
	public Date getProssimaRevisione() {
		return prossimaRevisione;
	}

	public void setProssimaRevisione(Date prossimaRevisione) {
		this.prossimaRevisione = prossimaRevisione;
	}

	public String getMarca() {
		return marca;
	}

	public String getModello() {
		return modello;
	}

	public String getTarga() {
		return targa;
	}

	public double getConsumo() {
		return consumo;
	}

	public Date getImmatricolazione() {
		return immatricolazione;
	}
	
	
}
