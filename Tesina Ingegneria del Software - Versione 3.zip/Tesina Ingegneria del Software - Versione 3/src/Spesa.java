import java.util.List;

public class Spesa {

	public double Costo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Acquisto")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}
}
