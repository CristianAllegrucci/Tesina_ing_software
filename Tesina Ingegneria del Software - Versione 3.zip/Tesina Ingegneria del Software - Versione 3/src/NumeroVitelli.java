import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class NumeroVitelli implements StatisticaSuGruppi{

	int mesi;
	double peso;
	
	//int mesi = 12;
	//double peso = 250;
	// il costruttore mi serve se penso che possa cambiare il criterio di classificazione dei vitelli
	
	public NumeroVitelli(int mesi, double peso)
	{
		// 
		this.mesi=mesi;
		this.peso=peso;
		
	}
	
	@Override
	public int statistica(Gruppi g) {
		
		List<Bovino> lista = new FiltraVitelli(peso).filtra(g);
		
		return lista.size();
	}

}
