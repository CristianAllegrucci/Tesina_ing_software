import java.util.Date;

// la classe astratta Pagamento serve come base per le classi venditaBestiame, venditaProdotti, o venditaCarne(se l'azienda prevede il macello per vendita diretta di carne o eventuale lavorazione e successiva vendita dei lavorati)
// si pu� usare anche per gli acquisti dell'azienda
public abstract class Pagamento {

	//attributi comuni alle vendite
	private Date dataFattura;
	private Date dataPagamento;
	private double prezzoVendita;
	
	public Pagamento(Date dataVendita, Date dataPagamento, double prezzoVendita) {
		super();
		this.dataFattura = dataFattura;
		this.dataPagamento = dataPagamento;
		this.prezzoVendita = prezzoVendita;
	}

	public Date getDataFattura() {
		return dataFattura;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public double getPrezzoVendita() {
		return prezzoVendita;
	}
	
}
