import java.util.Date;

// vendita di bestiame vivo
public class VenditaBestiame extends Pagamento{
	
	private int unit�Vendute;

	public VenditaBestiame(Date dataFattura, Date dataPagamento, double prezzoVendita, int unit�) {
		super(dataFattura, dataPagamento, prezzoVendita);
		this.unit�Vendute=unit�;
			
		// TODO Auto-generated constructor stub
	}
	

}
