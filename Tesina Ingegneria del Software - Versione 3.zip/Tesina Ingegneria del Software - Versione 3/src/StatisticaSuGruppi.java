
public interface StatisticaSuGruppi {

	public int statistica(Gruppi g);
}
