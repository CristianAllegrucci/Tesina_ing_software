import java.time.LocalDate;
import java.util.Date;

// si potrebbe valutare di inserire questa come estenzione di un'eventuale classe astratta "Bestiame", in ottica di una futura espansione dell'azienda con altri animali (polli, maiali ecc...)
public class Bovino {

	private int matricola;
	
	private String razza;
	private String sesso; 
	//private Date nascita;
	private LocalDate nascita;
	
	private double peso;
	
	// private int parti; 
	// da rivedere
	
	public Bovino(int matricola, String razza, String sesso, LocalDate nascita) {
		super();
		this.matricola = matricola;
		this.razza = razza;
		this.sesso = sesso;
		this.nascita = nascita;
	}

	public int getMatricola() {
		return matricola;
	}

	public String getRazza() {
		return razza;
	}

	public String getSesso() {
		return sesso;
	}

	public LocalDate getNascita() {
		return nascita;
	}

	public double getPeso()
	{
		return peso;
	}
	
}
