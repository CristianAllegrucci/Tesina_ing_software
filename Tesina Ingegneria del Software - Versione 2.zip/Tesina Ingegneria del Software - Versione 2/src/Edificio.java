
public class Edificio {

	private String id;
	private double superficie;
	private double vani;
	private double capienza;
	
	public Edificio(String id, double superficie, double vani, double capienza) {
		this.id = id;
		this.superficie = superficie;
		this.vani = vani;
		this.capienza = capienza;
	}

	public String getId() {
		return id;
	}

	public double getSuperficie() {
		return superficie;
	}

	public double getVani() {
		return vani;
	}

	public double getCapienza() {
		return capienza;
	}

	

}
