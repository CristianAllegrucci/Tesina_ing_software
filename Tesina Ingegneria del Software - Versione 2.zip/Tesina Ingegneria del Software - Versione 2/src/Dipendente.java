import java.time.LocalDate;

public class Dipendente {
	
	private String nome;
	private String cognome;
	private LocalDate DataDiNascita;
	
	public Dipendente(String nome, String cognome, LocalDate dataDiNascita) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.DataDiNascita = dataDiNascita;
	}
	
	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public LocalDate getDataDiNascita() {
		return DataDiNascita;
	}

	
	
}
