// versione 2 di stalla.java che estende la classe gruppi
// evito duplicazione del codice

public class Stalla extends Gruppi{
	
	private Edificio stalla;	// da creare classe in cui definire gli stabili che possono essere utilizzati
	// e classificarli in base alla capienza e alla dimensione

	public Stalla(String codice, Edificio stalla) {
		super(codice);
		this.stalla = stalla;
		// TODO Auto-generated constructor stub
	}
	
	// si pu� mettere quanto segue con un interfaccia 
}
