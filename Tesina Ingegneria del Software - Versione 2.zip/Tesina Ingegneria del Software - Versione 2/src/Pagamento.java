import java.util.Date;

public class Pagamento {

	private Date dataFattura;
	private Date dataPagamento;
	private double prezzo;
	private String tipologia;
	
	public Pagamento(Date dataFattura, Date dataPagamento, double prezzo, String tipologia) {
		super();
		this.tipologia = tipologia;
		this.dataFattura = dataFattura;
		this.dataPagamento = dataPagamento;
		this.prezzo = prezzo;
	}

	public Date getDataFattura() {
		return dataFattura;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public double getPrezzo() {
		return prezzo;
	}
	
	public String getTipologia(){
		return tipologia;
	}
	
}
