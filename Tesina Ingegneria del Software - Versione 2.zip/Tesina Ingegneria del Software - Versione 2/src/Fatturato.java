import java.util.List;

public class Fatturato {

	public double Ricavo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Vendita")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}
}
