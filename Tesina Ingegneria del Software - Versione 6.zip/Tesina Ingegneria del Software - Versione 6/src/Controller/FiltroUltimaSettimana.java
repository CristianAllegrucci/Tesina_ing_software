package Controller;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

import Model.Pagamento;

public class FiltroUltimaSettimana extends FiltroPeriodoGenerico implements FiltroTemporale {

	public FiltroUltimaSettimana() {
		super(LocalDate.now().plusDays(-7), LocalDate.now());
	}

}
