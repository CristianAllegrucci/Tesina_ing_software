package Controller;

import java.util.List;

import Model.Bovino;

public class FiltraBovini extends FiltraOggetti {

	public FiltraBovini() {
		super(new Bovino());
	}


}
