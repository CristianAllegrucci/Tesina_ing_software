package Controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.management.openmbean.OpenMBeanParameterInfo;
import javax.management.openmbean.OpenType;

import Model.Pagamento;
//DA RIGUARDARE
public abstract class CalcolaPagamentoSuPeriodo implements 
OperazioneSuPagamentoSuPeriodoTemporale {

	private FiltroTemporale filtroTemporale;
	
	public CalcolaPagamentoSuPeriodo(FiltroTemporale filtroTemporale) {
		this.filtroTemporale = filtroTemporale;
	}

	@Override
	public double calcolaSuPeriodo(List<Pagamento> listaPagamenti) {
		List<Pagamento>listaPagamentiFiltrata=
				this.filtroTemporale.filtraTemporalmente(listaPagamenti);
		double totale=0;
		for (Pagamento pagamento : listaPagamentiFiltrata) {
			//in base alla verifica, 
			//vedo se considero una spesa o un ricavo
			if(verificaTipologiaSpesa(pagamento)==true){
				totale+=pagamento.getCosto();
			}
		}
		return totale;
	}

	protected abstract boolean verificaTipologiaSpesa(Pagamento pagamento);
}
