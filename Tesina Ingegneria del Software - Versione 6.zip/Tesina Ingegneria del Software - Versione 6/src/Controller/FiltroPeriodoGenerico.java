package Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Model.Pagamento;

public class FiltroPeriodoGenerico implements FiltroTemporale{

	LocalDate dataInizio;
	LocalDate dataFine;

	public FiltroPeriodoGenerico(LocalDate dataInizio, LocalDate dataFine) {
		super();
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
	}

	@Override
	public List<Pagamento> filtraTemporalmente(List<Pagamento> listaPagamenti) {

		List<Pagamento> listaFiltrata = new ArrayList<Pagamento>();

		for (Pagamento p: listaPagamenti)
		{
			if ( p.getDataFattura().isAfter(dataFine) && p.getDataFattura().isBefore(dataInizio))
			{
				listaFiltrata.add(p);
			}
		}
		return listaFiltrata;
	}

}
