package Controller;
import Model.Pagamento;
import Model.Spesa;

public class CalcolaSpesaSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaSpesaSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaSpesa(Pagamento pagamento) {
		boolean tipologia=false;
		
		if(pagamento instanceof Spesa) { 
			tipologia=true;
		}
		return tipologia;
	}
}
