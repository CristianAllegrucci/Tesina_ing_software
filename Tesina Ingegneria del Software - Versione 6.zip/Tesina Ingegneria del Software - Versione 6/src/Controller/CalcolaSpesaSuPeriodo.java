package Controller;
import Model.Pagamento;
import Model.Spesa;

public class CalcolaSpesaSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaSpesaSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaPagamento(Pagamento pagamento) {
		boolean appartenenza=false;
		if(pagamento instanceof Spesa) {
			appartenenza = true ;
		}	
		return appartenenza;
		}
	}

