package Controller;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

import Model.Pagamento;

public class FiltroUltimoMese extends FiltroPeriodoGenerico implements FiltroTemporale {

	public FiltroUltimoMese() {
		super(LocalDate.now().plusMonths(-1), LocalDate.now());
	}

}

