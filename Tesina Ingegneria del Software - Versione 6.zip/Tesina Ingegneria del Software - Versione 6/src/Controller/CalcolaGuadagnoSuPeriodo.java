package Controller;
import Model.Guadagno;
import Model.Pagamento;

public class CalcolaGuadagnoSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaGuadagnoSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaSpesa(Pagamento pagamento) {
		boolean tipologia=false;
		if(pagamento instanceof Guadagno) {
			tipologia = false ;
		}	
		return tipologia;
		}

}
