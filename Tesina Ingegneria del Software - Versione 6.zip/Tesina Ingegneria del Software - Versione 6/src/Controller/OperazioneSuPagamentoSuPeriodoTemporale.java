package Controller;
import java.util.List;

import Model.Pagamento;

public interface OperazioneSuPagamentoSuPeriodoTemporale {

	public double calcolaSuPeriodo(List<Pagamento>listaPagamenti);
}
