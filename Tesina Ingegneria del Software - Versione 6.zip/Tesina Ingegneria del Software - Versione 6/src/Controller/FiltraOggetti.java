package Controller;

import java.util.ArrayList;
import java.util.List;

public abstract class FiltraOggetti {
	
	private Object filtro;
	
	public FiltraOggetti(Object filtro) {
		super();
		this.filtro = filtro;
	}

	public List<Object> filtra(List<Object> list){
		List<Object>listaFiltrata=
				new ArrayList<Object>();
		for (Object object : list) {
			if(object.getClass().isInstance(filtro.getClass())) {
				listaFiltrata.add(object);
			}
		}
		return listaFiltrata;
	}
}
