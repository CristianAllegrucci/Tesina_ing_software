package View;

import Controller.OperazioneSuPagamentoSuPeriodoTemporale;
import Model.Azienda;
import Model.Bovino;
import Model.Dipendente;
import Model.Pagamento;
import Model.Spesa;

public class GestoreAzienda {

	Azienda azienda = Azienda.getIstanza();

	public GestoreAzienda(Azienda azienda) {
		this.azienda = azienda;
	}

	// gestione dipendenti
	public void aggiungiDidendente(Dipendente dipendente) {
		if (azienda.getListaDipendente().contains(dipendente)) {
			System.out.println("Errore, " + dipendente.toString() +
					"già registrato");
		} else {
			azienda.getListaDipendente().add(dipendente);
		}
	}

	// ho eliminato il parametro di input Dipendente dipendente
	// perche non utilizzato
	public void rimuoviDidendente(Dipendente dipendente) {
		azienda.rimuoviDipendente(dipendente);

	}

	// gestione bovini
	public void aggiungiBovino(Bovino bovino) {
		if (azienda.getListaBovini().contains(bovino)) {
			System.out.println(bovino.toString() + "già registrato");
		} else {
			azienda.getListaBovini().add(bovino);
		}
	}

	// stessa cosa, ho eliminato bovino come parametro di input
	public void rimuoviBovino(Bovino bovino) {
		if (azienda.getListaBovini().size() == 0) {
			System.out.println("Lista bovini vuota, "
					+ "impossibile rimuovere");
		} else {
			if (azienda.getListaBovini().contains(bovino)) {
				azienda.rimuoviBovino(bovino);
			}
		}
	}

	// fattura
	public void aggiungiFattura(Spesa spesa) {
		if(azienda.getListaSpese().contains(spesa)) {
			System.out.println("La lista contiene già questo elemento");
		}else {
		azienda.getListaSpese().add(spesa);
	}
		}

	/*
	 * metodo per richiamare lo strategy sulle operazioni di pagamento. sul main mi
	 * preoccupero di passare il filtro e il tipo di costo da calcolare
	 */
	public double calcolaPagamentoSuPeriodo(OperazioneSuPagamentoSuPeriodoTemporale op) {
		return op.calcolaSuPeriodo(azienda.getListaFatture());
	}
}
