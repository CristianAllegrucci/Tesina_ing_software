package Model;
import java.time.LocalDate;
import java.util.List;
/*faccio diventare astratta cosi posso distinguere
 * le due classi concrete, spesa e costo, senza fare il controllo
 * mediante il confronto di Stringhe(pagamento.getTipologia()=="Acquisto")
 * che sono le cose da evitare che ha detto ilprof*/
public abstract class Pagamento {

	private LocalDate dataFattura;
	private double costo;
	
	public Pagamento(LocalDate dataFattura, double costo) {
		this.dataFattura = dataFattura;
		this.costo=costo;
	}

	public LocalDate getDataFattura() {
		return dataFattura;
	}

	public double getCosto() {
		return costo;
	}

	public void setDataFattura(LocalDate dataFattura) {
		this.dataFattura = dataFattura;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}
}



