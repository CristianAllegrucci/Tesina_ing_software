package Model;

public class Edificio {

	private String id;
	private double superficie;
	private int vani;// l'ho messo int, intendo numero di vani/spazi/stanze
	// ho eliminato capienza, perche è ridondante con superficie

	public Edificio(String id, double superficie, int vani) {
		this.id = id;
		this.superficie = superficie;
		this.vani = vani;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setSuperficie(double superficie) {
		this.superficie = superficie;
	}

	public void setVani(int vani) {
		this.vani = vani;
	}

	public String getId() {
		return id;
	}

	public double getSuperficie() {
		return superficie;
	}

	public double getVani() {
		return vani;
	}

}
