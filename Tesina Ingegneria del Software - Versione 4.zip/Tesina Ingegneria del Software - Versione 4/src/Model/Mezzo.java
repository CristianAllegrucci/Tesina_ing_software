package Model;
import java.util.Date;

public class Mezzo {
	
	private String marca;
	private String modello;
	
	private String targa;	// nel formato LLnnnLL es. AA000AA - va inserito un controllo sulla validit�

	private double consumo;
	
	private Date immatricolazione;
	private Date prossimaRevisione;

	public Mezzo(String marca, String modello, String targa, double consumo, Date immatricolazione,
			Date prossimaRevisione) {
		// super();
		this.marca = marca;
		this.modello = modello;
		this.targa = targa;
		this.consumo = consumo;
		this.immatricolazione = immatricolazione;
		this.prossimaRevisione = prossimaRevisione;
	}
	
	public Date getProssimaRevisione() {
		return prossimaRevisione;
	}

	public void setProssimaRevisione(Date prossimaRevisione) {
		this.prossimaRevisione = prossimaRevisione;
	}

	public String getMarca() {
		return marca;
	}

	public String getModello() {
		return modello;
	}

	public String getTarga() {
		return targa;
	}

	public double getConsumo() {
		return consumo;
	}

	public Date getImmatricolazione() {
		return immatricolazione;
	}
	
	
}
