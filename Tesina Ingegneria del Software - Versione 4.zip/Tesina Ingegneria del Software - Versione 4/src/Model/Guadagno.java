package Model;
import java.util.Date;
import java.util.List;
//vecchio fatturato
public class Guadagno extends Pagamento{

	public Guadagno(Date dataFattura, double costo) {
		super(dataFattura, costo);
	}

	
	/*public double Ricavo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Vendita")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}*/
}
