package Model;
import java.util.LinkedList;
import java.util.List;
/*Ho spostato tutte le funzioni in gestore azienda in modo da lasciare azienda
 * piu pulita*/
public class Azienda {

	// Dati dell'azienda
	private String nome;
	private String citta;
	private String indirizzo;
	//il telefono lo metterei int nonostate il commento
	private String telefono; // no int perch� potrebbe ignorare eventuali 0 iniziali 0039-075.... -> 39-....
	//ho messo int perche in p.iva ci sono tutti interi senza lettere
	private int partitaIva;
	private List<Pagamento> listaFatture;

	// Risorse
	private List<Dipendente> listaDipendente;
	private List<Bovino> listaBovini;

	// Costruttore
	public Azienda(String nome, String citta, String indirizzo, String telefono, 
			int partitaIva) {
		super();
		this.nome = nome;
		this.citta = citta;
		this.indirizzo = indirizzo;
		this.telefono = telefono;
		this.partitaIva = partitaIva;
		this.listaDipendente = new LinkedList<>();
		this.listaBovini = new LinkedList<>();
		this.listaFatture = new LinkedList<>();
	}

	public String getNome() {
		return nome;
	}

	public List<Pagamento> getListaFatture() {
		return listaFatture;
	}

	public void setListaFatture(List<Pagamento> listaFatture) {
		this.listaFatture = listaFatture;
	}

	public List<Dipendente> getListaDipendente() {
		return listaDipendente;
	}

	public void setListaDipendente(List<Dipendente> listaDipendente) {
		this.listaDipendente = listaDipendente;
	}

	public List<Bovino> getListaBovini() {
		return listaBovini;
	}

	public void setListaBovini(List<Bovino> listaBovini) {
		this.listaBovini = listaBovini;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public void setPartitaIva(int partitaIva) {
		this.partitaIva = partitaIva;
	}

	public String getCitta() {
		return citta;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public String getTelefono() {
		return telefono;
	}

	public int getPartitaIva() {
		return partitaIva;
	}

}
