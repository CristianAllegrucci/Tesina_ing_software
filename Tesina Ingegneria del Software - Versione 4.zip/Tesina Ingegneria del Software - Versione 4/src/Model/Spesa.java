package Model;
import java.util.Date;
import java.util.List;

public class Spesa extends Pagamento {
	
	public Spesa(Date dataFattura, double costo) {
		super(dataFattura, costo);
	}

/*	public double Costo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Acquisto")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}*/

}
