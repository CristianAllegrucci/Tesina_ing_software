package Model;
import java.util.Date;
import java.util.List;
/*faccio diventare astratta cosi posso distinguere
 * le due classi concrete, spesa e costo, senza fare il controllo
 * mediante il confronto di Stringhe(pagamento.getTipologia()=="Acquisto")
 * che sono le cose da evitare che ha detto ilprof*/
public abstract class Pagamento {

	private Date dataFattura;
	private double costo;
	
	public Pagamento(Date dataFattura, double costo) {
		this.dataFattura = dataFattura;
		this.costo=costo;
	}

	public Date getDataFattura() {
		return dataFattura;
	}

	public double getCosto() {
		return costo;
	}

	public void setDataFattura(Date dataFattura) {
		this.dataFattura = dataFattura;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}
}



