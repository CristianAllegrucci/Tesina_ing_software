package Controller;
import Model.Pagamento;
import Model.Spesa;

public class CalcolaSpesaSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaSpesaSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaPagamento(Pagamento pagamento) {
		boolean appartenenza=false;
		if(pagamento.getClass().isInstance(Spesa.class)) {
			appartenenza = true ;
		}	
		return appartenenza;
		}
	}

