package Controller;
import Model.Guadagno;
import Model.Pagamento;

public class CalcolaGuadagnoSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaGuadagnoSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaPagamento(Pagamento pagamento) {
		boolean appartenenza=false;
		if(pagamento.getClass().isInstance(Guadagno.class)) {
			appartenenza = true ;
		}	
		return appartenenza;
		}

}
