package Controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Model.Pagamento;

public class FiltroUltimaSettimana implements FiltroTemporale {

	public List<Pagamento> filtraTemporalmente(List<Pagamento> listaPagamenti) {
		Date d = new Date();
		long unaSettimanaFa = 7 * 24 * 60 * 60 * 1000;
		List<Pagamento> listaFiltrata = new ArrayList<Pagamento>();

		for (Pagamento pagamento : listaPagamenti) {
			if (pagamento.getDataFattura().getTime() < (d.getTime() - unaSettimanaFa)) {
				listaFiltrata.add(pagamento);
			}
		}
		return listaFiltrata;
	}

}
