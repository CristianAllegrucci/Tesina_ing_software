package Controller;
import Model.Pagamento;
import Model.Spesa;

public class CalcolaSpesaSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaSpesaSuPeriodo(FiltraPagamenti filtro) {
		super(filtro);
	}

	@Override
	protected boolean verificaTipologia(Pagamento pagamento) {		
		if(pagamento instanceof Spesa) { 
			return true;
		}else {
		return false;
	}
}
	}
