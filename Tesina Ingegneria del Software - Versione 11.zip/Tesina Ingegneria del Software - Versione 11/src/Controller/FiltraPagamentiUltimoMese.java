package Controller;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

import Model.Pagamento;

public class FiltraPagamentiUltimoMese extends FiltraPagamenti{

	public FiltraPagamentiUltimoMese() {
		super(LocalDate.now().minusMonths(1), LocalDate.now());
	}

}

