package Controller;

import java.util.ArrayList;
import java.util.List;

import Model.Bovino;
//Calcolo tasso natalità dall'istante in cui lo eseguo
//Il tasso di natalità è il numero annuo di nascite ogni cento abitanti.


public class TassoNatalita implements StatisticaBovini{
	/* 
	 * n(x)=N(x)*100/(P(x-1)+P(x)/2
	 * NB Riadattato non al 31/12 ma dal momento in cui si richiede il calcolo
n(x)= tasso di natalità dell'anno x (espresso in nascite per mille abitanti)
N(x)= numero dei nati nell'anno x
P(x)= popolazione al 31/12 dell'anno x
P(x-1)= popolazione al 31/12 dell'anno precedente all'anno x.

	*/
	
	private double nuoviNati;
	private double popolazioneAttuale;
	private double popolazioneAdUnAnnoFa;
	
	public TassoNatalita(double nuoviNati, double popolazioneAttuale, double popolazioneAdUnAnnoFa) {
		this.nuoviNati = nuoviNati;
		this.popolazioneAttuale = popolazioneAttuale;
		this.popolazioneAdUnAnnoFa = popolazioneAdUnAnnoFa;
	}


	public double calcola() {
		return (nuoviNati*100)/(
				(popolazioneAttuale+popolazioneAdUnAnnoFa)/2);
	}

	
}
