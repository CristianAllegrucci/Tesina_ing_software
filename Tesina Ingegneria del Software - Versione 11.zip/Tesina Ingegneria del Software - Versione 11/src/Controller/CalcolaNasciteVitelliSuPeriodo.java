package Controller;

import java.util.List;

import Model.Bovino;

public class CalcolaNasciteVitelliSuPeriodo 
implements OperazioneSuPeriodoTemporale <Bovino> {

	private FiltroTemporale filtroTemporale;
	
	public CalcolaNasciteVitelliSuPeriodo(FiltroTemporale filtroTemporale) {
		this.filtroTemporale = filtroTemporale;
	}

public double calcolaSuPeriodo(List<Bovino> listaBovini) {
		List<Bovino>listaFiltrata=
				filtroTemporale.filtraTemporalmente(listaBovini);
		double tot=listaFiltrata.size();
		return tot;
	}

}
