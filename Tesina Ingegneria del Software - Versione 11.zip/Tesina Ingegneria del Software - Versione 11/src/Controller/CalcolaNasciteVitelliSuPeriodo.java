package Controller;

import java.util.List;

import Model.Bovino;

public class CalcolaNasciteVitelliSuPeriodo 
implements OperazioneSuPeriodoTemporale <Bovino> {

	private FiltraNasciteVitelli filtro;
	
	public CalcolaNasciteVitelliSuPeriodo(FiltraNasciteVitelli filtro) {
		this.filtro = filtro;
	}

public double calcolaSuPeriodo(List<Bovino> listaBovini) {
		List<Bovino>listaFiltrata=
				filtro.filtraTemporalmente(listaBovini);
		double tot=listaFiltrata.size();
		return tot;
	}

}
