package Controller;
import Model.Guadagno;
import Model.Pagamento;

public class CalcolaGuadagnoSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaGuadagnoSuPeriodo(FiltraPagamenti filtro) {
		super(filtro); 
	}

	@Override
	protected boolean verificaTipologia(Pagamento pagamento) {
		if(pagamento instanceof Guadagno) {
			return true ;
		}else {
			return false;
		}
	}
}
