package Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Model.Pagamento;

public class FiltroPeriodoGenerico  {

	LocalDate dataInizio;
	LocalDate dataFine;

	public FiltroPeriodoGenerico(LocalDate dataInizio, LocalDate dataFine) {
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
	}
}