package Controller;
import java.util.List;

import Model.Pagamento;

public interface OperazioneSuPeriodoTemporale<T> {

	public double calcolaSuPeriodo(List<T>lista);
}
