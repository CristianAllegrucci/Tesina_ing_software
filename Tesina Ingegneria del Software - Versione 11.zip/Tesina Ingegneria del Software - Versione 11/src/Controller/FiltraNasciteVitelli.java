package Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Model.Bovino;

public class FiltraNasciteVitelli extends FiltroPeriodoGenerico
implements FiltroTemporale<Bovino>{

	public FiltraNasciteVitelli(LocalDate dataInizio, LocalDate dataFine) {
		super(dataInizio, dataFine);
	}

	@Override
	public List<Bovino> filtraTemporalmente(List<Bovino> listaBovini) {
		List<Bovino> listaFiltrata = new ArrayList<Bovino>();

		for (Bovino bovino: listaBovini)
		{
			if (bovino.getDataDiNascita().isAfter(dataInizio) 
					&& bovino.getDataDiNascita().isBefore(dataFine))
			{
				listaFiltrata.add(bovino);
			}
		}
		return listaFiltrata;
	}

}