package Controller;

import Model.Mezzo;

public interface OsservatoreMezzo {

	public void osserva(Mezzo mezzo);

}
