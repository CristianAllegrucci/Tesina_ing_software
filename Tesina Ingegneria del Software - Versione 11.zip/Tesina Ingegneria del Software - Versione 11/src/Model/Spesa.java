package Model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Spesa extends Pagamento {
	
	public Spesa(LocalDate dataFattura, double importo) {
		super(dataFattura, importo);
	}
}
