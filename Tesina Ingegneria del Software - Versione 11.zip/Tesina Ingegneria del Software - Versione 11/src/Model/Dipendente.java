package Model;

import java.time.LocalDate;

public class Dipendente {

	private String id;
	private String nome;
	private String cognome;
	private LocalDate dataDiNascita;

	
	public Dipendente(String id, String nome, String cognome, LocalDate dataDiNascita) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.dataDiNascita = dataDiNascita;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public void setDataDiNascita(LocalDate dataDiNascita) {
		this.dataDiNascita= dataDiNascita;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public LocalDate getDataDiNascita() {
		return dataDiNascita;
	}

}
