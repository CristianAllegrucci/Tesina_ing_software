package Model;
import java.time.LocalDate;
import java.util.List;
//vecchio fatturato
public class Guadagno extends Pagamento{

	public Guadagno(LocalDate dataFattura, double importo) {
		super(dataFattura, importo);
	}

}
