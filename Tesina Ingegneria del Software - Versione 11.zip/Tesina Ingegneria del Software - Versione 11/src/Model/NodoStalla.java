package Model;

import java.util.List;

public interface NodoStalla {
	
	public List<Bovino> getBovini();
	public int calcolaNumBovini();
}
