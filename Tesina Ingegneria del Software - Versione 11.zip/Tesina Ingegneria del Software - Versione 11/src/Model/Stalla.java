package Model;
import java.util.ArrayList;
import java.util.List;

public class Stalla implements NodoStalla {
	
	
	private List<Bovino>listaBovini=
			new ArrayList<Bovino>();
	//costruttore
	public Stalla(List<Bovino>listaBovini) {
		this.listaBovini=listaBovini;
	}
	
	public void aggiungiBovino(Bovino bovino) {
		listaBovini.add(bovino);
	}
	
	@Override
	public int calcolaNumBovini() {
		int totale=0;
		for (Bovino bovino : listaBovini) {
			totale+=1;
		}
		return totale;
	}

	@Override
	public List<Bovino> getBovini() {
		return this.listaBovini;
	}
	}