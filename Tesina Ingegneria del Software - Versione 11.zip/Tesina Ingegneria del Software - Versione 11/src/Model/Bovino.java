package Model;

import java.time.LocalDate;

public class Bovino {

	private LocalDate dataDiNascita;
	private double peso;
	private String matricola;
	private String razza;
	private char sesso;
	

	public Bovino(LocalDate dataDiNascita, double peso, String matricola, String razza, char sesso) {
		this.dataDiNascita = dataDiNascita;
		this.peso = peso;
		this.matricola = matricola;
		this.razza = razza;
		this.sesso = sesso;//si potrebbe fare boolean
	}
	//Costruttore da usare nei test
	public Bovino(LocalDate dataDiNascita) {
		this.dataDiNascita=dataDiNascita;
	}

	public LocalDate getDataDiNascita() {
		return dataDiNascita;
	}

	public double getPeso() {
		return peso;
	}

	public String getMatricola() {
		return matricola;
	}
	
	public String getRazza() {
		return razza;
	}

	public char getSesso() {
		return sesso;
	}
}
