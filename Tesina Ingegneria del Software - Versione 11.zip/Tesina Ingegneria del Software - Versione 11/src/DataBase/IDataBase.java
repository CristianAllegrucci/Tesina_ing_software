package DataBase;
import java.sql.*;

public interface IDataBase {
	
	public Connection connessioneDB();
	public void chiudiConnessione();
	
	public void aggiornaDB(String query);
	public Statement creaDichiarazione();

}
