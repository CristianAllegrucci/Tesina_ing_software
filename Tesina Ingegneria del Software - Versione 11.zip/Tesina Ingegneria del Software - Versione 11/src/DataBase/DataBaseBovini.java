package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import Model.Azienda;
import Model.Bovino;
import Model.Dipendente;
import Model.Mezzo;
import View.GestoreAzienda;

public class DataBaseBovini implements IDataBase {
	private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_CONNECTION = "jdbc:mysql://localhost/DataBaseBovini?user=root&password=Password93.&useUnicode=true&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "Password93.";
	private Connection connessione;

	@Override
	public Connection connessioneDB() {
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			this.connessione = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return connessione;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return connessione;
	}

	@Override
	public void aggiornaDB(String query) {
		// Connection connection = connessioneDB();
		Statement stmt = null;
		try {
			this.connessione.setAutoCommit(false);
			stmt = this.connessione.createStatement();
			stmt.execute(query);
			stmt.close();
			this.connessione.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
			System.out.println("My Error: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void chiudiConnessione() {
		try {
			this.connessione.close();
		} catch (SQLException e) {
			System.out.println("Errore durante la chiusura del db: " + e.getLocalizedMessage());
		}
	}

	@Override
	public Statement creaDichiarazione() {
		Statement stmt = null;
		try {
			this.connessione.setAutoCommit(false);
			stmt = this.connessione.createStatement();
			this.connessione.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stmt;
	}

	// Lettura DataBase-Stampa il db sulla console
	public void leggiDB() throws SQLException {
		String jdbcUrl = this.DB_CONNECTION;
		Connection con = this.connessioneDB();
		Statement stmt = this.creaDichiarazione();
		String query = "SELECT * FROM Bovini ;";
		ResultSet rs = this.creaDichiarazione().executeQuery(query);
		try {
			while (rs.next()) {
				int numColumns = rs.getMetaData().getColumnCount();
				for (int i = 1; i <= numColumns; i++) {
					System.out.println("COLUMN " + i + " = " + rs.getObject(i));
				}
			}
		} finally {
			try {
				rs.close();
			} catch (Throwable ignore) {
			} finally {
				try {
					stmt.close();
				} catch (Throwable ignore) {
				}

				finally {
					try {
						con.close();
					} catch (Throwable ignore) {
					}
				}
				System.out.println("DB Connesso!");
				con.close();

			}
		}
	}

	// Cambiando i valori potremmocreare le varie tabelle del nostro db
	public void creaTabelle() {
		String prefisso = "CREATE TABLE IF NOT EXISTS ";
		// Tabella bovini
		this.aggiornaDB(prefisso + "`DataBaseBovini`.`Bovini` (\r\n" + "  `matricola` VARCHAR(14) NOT NULL,\r\n"
				+ "  `peso` DOUBLE NOT NULL,\r\n" + "  `razza` VARCHAR(20) NOT NULL,\r\n"
				+ "  `dataDiNascita` DATE NOT NULL,\r\n" + "  `sesso` ENUM('M', 'F') NOT NULL,\r\n"
				+ "  PRIMARY KEY (`matricola`))");

		// Tabella dipendenti
		this.aggiornaDB(prefisso + "`DataBaseBovini`.`Dipendenti` (\r\n" + "  `id` VARCHAR(5) NOT NULL,\r\n"
				+ "  `nome` VARCHAR(15)NOT NULL,\r\n" + "  `cognome` VARCHAR(15) NOT NULL,\r\n"
				+ "  `dataDiNascita` DATE NOT NULL,\r\n" + "  PRIMARY KEY (`id`))");

		// Tabella mezzi
		this.aggiornaDB(prefisso + "`DataBaseBovini`.`Mezzi` (\r\n" + "  `marca` VARCHAR(20) NOT NULL,\r\n"
				+ "  `modello` VARCHAR(20)NOT NULL,\r\n" + "  `targa` VARCHAR(7) NOT NULL,\r\n"
				+ "  `consumo` DOUBLE NOT NULL,\r\n" + "  `dataImmatricolazione` DATE NOT NULL,\r\n"
				+ "  `disponibile`BOOLEAN NOT NULL,\r\n" + " PRIMARY KEY (`targa`))");
//TINYINT(1)=booleanENUM('0','1')
	}

	public void cancellaTabelle() {
		this.aggiornaDB("DROP TABLE DataBaseBovini.Bovini");
		this.aggiornaDB("DROP TABLE DataBaseBovini.Dipendenti");
		this.aggiornaDB("DROP TABLE DataBaseBovini.Mezzi");

	}

	public void popolaBovini() {
		String query = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056000016240'" + "," + "'600'" + "," + "'Meticcio'"
				+ "," + "'1999-03-04'" + "," + "'F'" + ");";
		this.aggiornaDB(query);
		String queryDue = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056000016245'" + "," + "'750'" + ","
				+ "'Meticcio'" + "," + "'1999-03-10'" + "," + "'F'" + ");";
		this.aggiornaDB(queryDue);
		String queryTre = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056000081841'" + "," + "'580'" + ","
				+ "'Maremmana'" + "," + "'2002-06-04'" + "," + "'F'" + ");";
		this.aggiornaDB(queryTre);
		String queryQuattro = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990091886'" + "," + "'480'" + ","
				+ "'Meticcio'" + "," + "'2009-05-20'" + "," + "'F'" + ");";
		this.aggiornaDB(queryQuattro);
		String queryCinque = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990133565'" + "," + "'630'" + ","
				+ "'Maremmana'" + "," + "'2013-02-25'" + "," + "'F'" + ");";
		this.aggiornaDB(queryCinque);
		String querySei = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990141314'" + "," + "'760'" + ","
				+ "'Maremmana'" + "," + "'2013-06-22'" + "," + "'F'" + ");";
		this.aggiornaDB(querySei);
		String querySette = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990141316'" + "," + "'730'" + ","
				+ "'Maremmana'" + "," + "'2013-07-07'" + "," + "'F'" + ");";
		this.aggiornaDB(querySette);
		String queryOtto = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990141317'" + "," + "'810'" + ","
				+ "'Maremmana'" + "," + "'2013-07-11'" + "," + "'M'" + ");";
		this.aggiornaDB(queryOtto);
		String queryNove = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990141320'" + "," + "'520'" + ","
				+ "'Maremmana'" + "," + "'2013-07-14'" + "," + "'F'" + ");";
		this.aggiornaDB(queryNove);
		String queryDieci = "INSERT INTO DataBaseBovini.Bovini VALUES ('IT056990133552'" + "," + "'660'" + ","
				+ "'Maremmana'" + "," + "'2013-01-08'" + "," + "'F'" + ");";
		this.aggiornaDB(queryDieci);	
	}
	
	public void popolaMezzi() {
		String query = "INSERT INTO DataBaseBovini.Mezzi VALUES ('john deere'" + "," + "'5050E'" + "," + "'AB123CD'"
				+ ","+"'30'"+"," + "'2015-05-07'" + "," + "true" + ");";
		this.aggiornaDB(query);
		String queryDue = "INSERT INTO DataBaseBovini.Mezzi VALUES ('john deere'" + "," + "'5090M'" + "," + "'EF123CD'"
				+ ","+"'30'"+"," + "'2017-05-07'" + "," + "true" + ");";
		this.aggiornaDB(queryDue);	
	}
	
	public void popolaDipendenti() {
		String query = "INSERT INTO DataBaseBovini.Dipendenti VALUES ('DIP01'" +
		"," + "'Mario'" + "," +"'Rossi'"+"," + "'1970-08-08'"+ ");";
		this.aggiornaDB(query);
		String queryDue = "INSERT INTO DataBaseBovini.Dipendenti VALUES ('DIP02'" +
		"," + "'Giuseppe'"+"," + "'Verdi'"+"," + "'1983-05-07'"+ ");";
		this.aggiornaDB(queryDue);	
	}
	
	public void inserisciBovino(Bovino bovino) {
		String query = "INSERT INTO Bovini VALUES ('" + bovino.getMatricola() + "','" + bovino.getPeso() + "','"
				+ bovino.getRazza() + "','" + bovino.getDataDiNascita() + "','" + bovino.getSesso() + "')";
		this.aggiornaDB(query);
	}
	public void inserisciMezzo(Mezzo mezzo) {
		String query = "INSERT INTO Mezzi VALUES ('" + mezzo.getMarca() + "','" + mezzo.getModello() + "','"
				+ mezzo.getTarga() + "','" + mezzo.getConsumo() + "','" +mezzo.getImmatricolazione() + "',"+ mezzo.isDisponibile()+");";
		this.aggiornaDB(query);
	}
	public void inserisciDipendente(Dipendente dipendente) {
		String query = "INSERT INTO Dipendenti VALUES ('" + dipendente.getId() + "','" + dipendente.getNome() + "','"
				+ dipendente.getCognome() + "','" + dipendente.getDataDiNascita() +"');";
		this.aggiornaDB(query);
	}
	
}



