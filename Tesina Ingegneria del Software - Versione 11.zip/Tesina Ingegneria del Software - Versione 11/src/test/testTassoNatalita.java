package test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import Controller.CalcolaNasciteVitelliSuPeriodo;
import Controller.FiltraNasciteVitelliUltimoAnno;
import Controller.FiltroTemporale;
import Controller.TassoNatalita;
import Model.Azienda;
import Model.Bovino;
import View.GestoreAzienda;

public class testTassoNatalita {
/*
	public double tassoDiNatalita() {
		FiltroTemporale<Bovino> filtro = new FiltraNasciteVitelliUltimoAnno();
		double nuoviNati = new CalcolaNasciteVitelliSuPeriodo(filtro).calcolaSuPeriodo(azienda.getListaBovini());
		double popolazioneCorrente = azienda.getListaBovini().size();
		double popolazioneAdUnAnnoFa = azienda.getListaBovini().size() - nuoviNati;

		return new TassoNatalita(nuoviNati, popolazioneCorrente, popolazioneAdUnAnnoFa).calcola();
	}*/
	@Test
	
		public void testTassoNatalita() {
			GestoreAzienda gestoreAzienda=
					new GestoreAzienda(Azienda.getIstanza());
			List<Bovino>bovini=Azienda.getIstanza().getListaBovini();
			
			Bovino a=new Bovino(LocalDate.of(2019, 1, 1));
			Bovino b=new Bovino(LocalDate.of(2018, 12, 3));
			Bovino c=new Bovino(LocalDate.of(2018, 11, 10));
			Bovino d=new Bovino(LocalDate.of(2018, 11, 3));
			Bovino e=new Bovino(LocalDate.of(2018, 10, 1));
			Bovino f=new Bovino(LocalDate.of(2018, 9, 9));
			Bovino g=new Bovino(LocalDate.of(2018, 7, 3));
			
			Bovino h=new Bovino(LocalDate.of(2015, 12, 22));
			Bovino i=new Bovino(LocalDate.of(2015, 3, 3));
			Bovino l=new Bovino(LocalDate.of(2014, 12, 11));
			Bovino m=new Bovino(LocalDate.of(2014, 5, 8));
			Bovino n=new Bovino(LocalDate.of(2013, 9, 27));
			Bovino o=new Bovino(LocalDate.of(2011, 6, 20));
			Bovino p=new Bovino(LocalDate.of(2014, 5, 8));
			Bovino q=new Bovino(LocalDate.of(2013, 9, 27));
			Bovino r=new Bovino(LocalDate.of(2011, 6, 20));
			Bovino s=new Bovino(LocalDate.of(2013, 9, 27));
			Bovino t=new Bovino(LocalDate.of(2011, 6, 20));
			Bovino u=new Bovino(LocalDate.of(2014, 5, 8));
			Bovino v=new Bovino(LocalDate.of(2013, 9, 27));
			Bovino z=new Bovino(LocalDate.of(2011, 6, 20));
			bovini.add(a);
			bovini.add(b);
			bovini.add(c);
			bovini.add(d);
			bovini.add(e);
			bovini.add(f);
			bovini.add(g);
			bovini.add(h);
			bovini.add(i);
			bovini.add(l);
			bovini.add(m);
			bovini.add(n);
			bovini.add(o);
			bovini.add(p);
			bovini.add(q);
			bovini.add(r);
			bovini.add(s);
			bovini.add(t);
			bovini.add(u);
			bovini.add(v);
			bovini.add(z);
			
			FiltroTemporale<Bovino> filtro = new FiltraNasciteVitelliUltimoAnno();
			double nuoviNati = new CalcolaNasciteVitelliSuPeriodo(filtro).calcolaSuPeriodo(bovini);
			double popolazioneCorrente = bovini.size();
			double popolazioneAdUnAnnoFa =bovini.size() - nuoviNati;
			TassoNatalita tassoNatalita=new TassoNatalita(nuoviNati, popolazioneCorrente, popolazioneAdUnAnnoFa);
			double valoreAtteso=(nuoviNati*100)/(
					(popolazioneCorrente+popolazioneAdUnAnnoFa)/2);//40
			assertEquals(tassoNatalita.calcola(),valoreAtteso,1);
			
		}
	}

