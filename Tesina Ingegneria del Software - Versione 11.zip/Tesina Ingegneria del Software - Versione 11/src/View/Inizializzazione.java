package View;

import Model.Azienda;

public class Inizializzazione {
	
	GestoreAzienda gestoreazienda = new GestoreAzienda(Azienda.getIstanza());
	
}
