package View;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Model.Azienda;
import Model.Bovino;
import Model.Guadagno;
import Model.Mezzo;
import Model.Pagamento;
import Model.Spesa;

public class Inizializzazione {

	private GestoreAzienda gestoreAzienda = new GestoreAzienda(Azienda.getIstanza());
	private List<Bovino> bovini = Azienda.getIstanza().getBovini();
	private List<Pagamento>spese=Azienda.getIstanza().getListaPagamenti();
	private List<Mezzo>listaMezziDisponibili = Azienda.getIstanza().getListaMezzi();

	public Inizializzazione(GestoreAzienda gestoreAzienda) {
		this.gestoreAzienda = gestoreAzienda;
	}
	
	public List<Mezzo> aggiungiMezzi(){
		 Mezzo a = new Mezzo("Lamborghini", "X321", "AA0005", 12, LocalDate.of(2019, 1, 1), true);
		  Mezzo b = new Mezzo("Lancia", "X421", "AA0007", 12.5, LocalDate.of(2019, 1, 1), false);
		  Mezzo c = new Mezzo("John Deere", "X322", "AA0805", 20, LocalDate.of(2019, 1, 1), true);
		  Mezzo d = new Mezzo("Landini", "X321", "AA0305", 12, LocalDate.of(2019, 1, 1), true);
		  Mezzo e = new Mezzo("Valtra", "X321", "AA1005", 12, LocalDate.of(2019, 1, 1), true);
		  Mezzo f = new Mezzo("CNH-Fiat Group", "T521", "AB0005", 12, LocalDate.of(2019, 1, 1), false);
		  Mezzo g = new Mezzo("Challenger", "P321", "FD0005", 12, LocalDate.of(2019, 1, 1), true);
		  Mezzo h = new Mezzo("White", "H321", "H30005", 12, LocalDate.of(2019, 1, 1), false);
		  Mezzo i = new Mezzo("TerraGator", "X621", "F40005", 12, LocalDate.of(2019, 1, 1), true);
		  listaMezziDisponibili.add(a);
		  listaMezziDisponibili.add(b);
		  listaMezziDisponibili.add(c);
		  listaMezziDisponibili.add(d);
		  listaMezziDisponibili.add(e);
		  listaMezziDisponibili.add(f);
		  listaMezziDisponibili.add(g);
		  listaMezziDisponibili.add(h);
		  listaMezziDisponibili.add(i);
		  return listaMezziDisponibili;
	}
	
	public List<Bovino> aggiungiBovini() {
		//nuovi nati
		Bovino a = new Bovino(LocalDate.of(2019, 1, 1));
		Bovino b = new Bovino(LocalDate.of(2018, 12, 3));
		Bovino c = new Bovino(LocalDate.of(2018, 11, 10));
		Bovino d = new Bovino(LocalDate.of(2018, 11, 3));
		Bovino e = new Bovino(LocalDate.of(2018, 10, 1));
		Bovino f = new Bovino(LocalDate.of(2018, 9, 9));
		Bovino g = new Bovino(LocalDate.of(2018, 7, 3));
		//vecchi nati
		Bovino h = new Bovino(LocalDate.of(2015, 12, 22));
		Bovino i = new Bovino(LocalDate.of(2015, 3, 3));
		Bovino l = new Bovino(LocalDate.of(2014, 12, 11));
		Bovino m = new Bovino(LocalDate.of(2014, 5, 8));
		Bovino n = new Bovino(LocalDate.of(2013, 9, 27));
		Bovino o = new Bovino(LocalDate.of(2011, 6, 20));
		Bovino p = new Bovino(LocalDate.of(2014, 5, 8));
		Bovino q = new Bovino(LocalDate.of(2013, 9, 27));
		Bovino r = new Bovino(LocalDate.of(2011, 6, 20));
		Bovino s = new Bovino(LocalDate.of(2013, 9, 27));
		Bovino t = new Bovino(LocalDate.of(2011, 6, 20));
		Bovino u = new Bovino(LocalDate.of(2014, 5, 8));
		Bovino v = new Bovino(LocalDate.of(2013, 9, 27));
		Bovino z = new Bovino(LocalDate.of(2011, 6, 20));
		bovini.add(a);
		bovini.add(b);
		bovini.add(c);
		bovini.add(d);
		bovini.add(e);
		bovini.add(f);
		bovini.add(g);
		bovini.add(h);
		bovini.add(i);
		bovini.add(l);
		bovini.add(m);
		bovini.add(n);
		bovini.add(o);
		bovini.add(p);
		bovini.add(q);
		bovini.add(r);
		bovini.add(s);
		bovini.add(t);
		bovini.add(u);
		bovini.add(v);
		bovini.add(z);
		return bovini;
	}
	public List<Pagamento>aggiungiPagamenti(){
		//spese ultima settimana
		Spesa a=new Spesa(LocalDate.now().minusDays(1), 100);
		Spesa b=new Spesa(LocalDate.now().minusDays(1), 100);
		Guadagno c=new Guadagno(LocalDate.now().minusDays(1), 100);
		Guadagno d=new Guadagno(LocalDate.now().minusDays(1), 100);
		Spesa e=new Spesa(LocalDate.now().minusDays(1), 100);
		Spesa f=new Spesa(LocalDate.now().minusDays(1), 100);
		//spese vecchie
		Spesa g=new Spesa(LocalDate.of(2015, 2, 2), 100);
		Spesa h=new Spesa(LocalDate.of(2015, 2, 2), 100);
		Guadagno i=new Guadagno(LocalDate.of(2015, 2, 2), 100);
		Spesa l=new Spesa(LocalDate.of(2015, 2, 2), 100);
		Spesa m=new Spesa(LocalDate.of(2015, 2, 2), 100);
		Spesa n=new Spesa(LocalDate.of(2015, 2, 2), 100);

		spese.add(a);
		spese.add(b);
		spese.add(c);
		spese.add(d);
		spese.add(e);
		spese.add(f);
		spese.add(g);
		spese.add(h);
		spese.add(i);
		spese.add(l);
		spese.add(m);
		spese.add(n);
		
		return spese;

	}

}
