package View;

import java.sql.SQLException;
import java.time.LocalDate;

import DataBase.DataBaseBovini;
import Model.Bovino;
import Model.Dipendente;
import Model.Mezzo;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		Inizializzazione i = new Inizializzazione();
		
		DataBaseBovini dataBaseBovini=
				new DataBaseBovini();
		dataBaseBovini.connessioneDB();
		
		dataBaseBovini.cancellaTabelle();
		dataBaseBovini.creaTabelle();
		dataBaseBovini.popolaBovini();
		dataBaseBovini.popolaMezzi();
	    dataBaseBovini.popolaDipendenti();
	    Bovino bovinoDaInserire=
			new Bovino(LocalDate.of(2005, 2, 1), 890, "IT056990008297", "Maremmana", 'F');
		dataBaseBovini.inserisciBovino(bovinoDaInserire);
		Mezzo mezzoDaInserire=
			new Mezzo("john deere", "6120M", "XX000WE", 30, LocalDate.of(2015, 5, 1), true);
		dataBaseBovini.inserisciMezzo(mezzoDaInserire);
		Dipendente dipendente =
				new Dipendente("DIP03","Cristian","Allegrucci",LocalDate.of(1994, 1, 29));
		dataBaseBovini.inserisciDipendente(dipendente);
		//dataBaseBovini.leggiDB();//chiude la connessione, non ho bisogno di usare ilmetodo chiudi connessione

	}
}
