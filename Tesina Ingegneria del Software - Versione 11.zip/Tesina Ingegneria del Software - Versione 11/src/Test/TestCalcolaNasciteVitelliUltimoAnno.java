package Test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import Controller.CalcolaNasciteVitelliSuPeriodo;
import Controller.FiltraNasciteVitelli;
import Controller.FiltraNasciteVitelliUltimoAnno;
import Controller.TassoNatalita;
import Model.Azienda;
import Model.Bovino;
import View.GestoreAzienda;
import View.Inizializzazione;

public class TestCalcolaNasciteVitelliUltimoAnno {

	@Test
	public void testCalcolaNasciteVitelliUltimoAnnoDaOra() {
		Inizializzazione i = new Inizializzazione
				(new GestoreAzienda(Azienda.getIstanza()));
		List<Bovino> bovini = i.aggiungiBovini();

		FiltraNasciteVitelli filtro = new FiltraNasciteVitelliUltimoAnno();
		double nuoviNati = new CalcolaNasciteVitelliSuPeriodo(filtro).
				calcolaSuPeriodo(bovini);
		double valoreAtteso = 7;
		assertEquals(nuoviNati, valoreAtteso, 1);

	}

}
