package Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import Controller.CalcolaPagamentoSuPeriodo;
import Controller.CalcolaSpesaSuPeriodo;
import Controller.FiltraPagamenti;
import Controller.FiltraPagamentiUltimaSettimana;
import Model.Azienda;
import Model.Pagamento;
import Model.Spesa;
import View.GestoreAzienda;
import View.Inizializzazione;

public class TestCalcolaSpesaUltimaSettimana {

	@Test
	public void testCalcolaSpesaUltimaSettimana() {
		Inizializzazione i=new Inizializzazione(new GestoreAzienda(Azienda.getIstanza()));	
		List<Pagamento>pagamenti=Azienda.getIstanza().getListaPagamenti();
		pagamenti=i.aggiungiPagamenti();
		FiltraPagamenti filtro=new FiltraPagamentiUltimaSettimana();
		CalcolaSpesaSuPeriodo c = new CalcolaSpesaSuPeriodo(filtro);
		double risultato = c.calcolaSuPeriodo(pagamenti);
		assertEquals(risultato,400,1);
	}

}






