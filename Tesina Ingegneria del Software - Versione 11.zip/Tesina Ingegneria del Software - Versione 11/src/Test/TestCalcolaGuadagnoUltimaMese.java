package Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import Controller.CalcolaGuadagnoSuPeriodo;
import Controller.CalcolaPagamentoSuPeriodo;
import Controller.CalcolaSpesaSuPeriodo;
import Controller.FiltraPagamenti;
import Controller.FiltraPagamentiUltimaSettimana;
import Controller.FiltraPagamentiUltimoMese;
import Model.Azienda;
import Model.Pagamento;
import Model.Spesa;
import View.GestoreAzienda;
import View.Inizializzazione;

public class TestCalcolaGuadagnoUltimaMese {

	@Test
	public void testCalcolaSpesaUltimaSettimana() {
		Inizializzazione i=new Inizializzazione(new GestoreAzienda(Azienda.getIstanza()));	
		List<Pagamento>pagamenti=Azienda.getIstanza().getListaPagamenti();
		pagamenti=i.aggiungiPagamenti();
		FiltraPagamenti filtro=new FiltraPagamentiUltimoMese();
		CalcolaGuadagnoSuPeriodo c = new CalcolaGuadagnoSuPeriodo(filtro);
		double risultato = c.calcolaSuPeriodo(pagamenti);

		assertEquals(risultato,200,1);
	}

}






