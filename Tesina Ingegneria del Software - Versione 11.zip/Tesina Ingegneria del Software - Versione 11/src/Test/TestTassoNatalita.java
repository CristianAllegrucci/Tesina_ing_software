package Test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import Controller.CalcolaNasciteVitelliSuPeriodo;
import Controller.FiltraNasciteVitelli;
import Controller.FiltraNasciteVitelliUltimoAnno;
import Controller.FiltroTemporale;
import Controller.TassoNatalita;
import Model.Azienda;
import Model.Bovino;
import View.GestoreAzienda;
import View.Inizializzazione;

public class TestTassoNatalita {
	@Test
	
		public void testTassoNatalita() {
			Inizializzazione i=new Inizializzazione(new GestoreAzienda(Azienda.getIstanza()));
			List<Bovino>bovini=i.aggiungiBovini();
			
			FiltraNasciteVitelli filtro = new FiltraNasciteVitelliUltimoAnno();
			double nuoviNati = new CalcolaNasciteVitelliSuPeriodo(filtro).
					calcolaSuPeriodo(bovini);
			double popolazioneCorrente = bovini.size();
			double popolazioneAdUnAnnoFa =bovini.size() - nuoviNati;
			TassoNatalita tassoNatalita=
					new TassoNatalita(nuoviNati, popolazioneCorrente, popolazioneAdUnAnnoFa);
			double valoreAtteso=(nuoviNati*100)/(
					(popolazioneCorrente+popolazioneAdUnAnnoFa)/2);
			System.out.println(valoreAtteso);//40
			assertEquals(tassoNatalita.calcola(),valoreAtteso,1);
			
		}
	}

