package Test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import Controller.CalcolaMezziDisponibili;
import Model.Azienda;
import Model.Mezzo;
import Model.Pagamento;
import View.GestoreAzienda;
import View.Inizializzazione;

public class TestMezziAttualmenteDisponibili {

	@Test
	public void testMezziAttualmenteDisponibili() {
		Inizializzazione i = new Inizializzazione(new GestoreAzienda(Azienda.getIstanza()));
		List<Mezzo> mezzi = Azienda.getIstanza().getListaMezzi();
		mezzi = i.aggiungiMezzi();

		CalcolaMezziDisponibili calcolaMezziDisponibili = new CalcolaMezziDisponibili();
		assertEquals(calcolaMezziDisponibili.calcolaMezziDisponibili(mezzi).size(), 6, 1);

	}

}
