package View;

import java.sql.SQLException;
import java.time.LocalDate;

import DataBase.DataBaseBovini;
import Model.Bovino;

public class Main {

	public static void main(String[] args) throws SQLException {
		DataBaseBovini dataBaseBovini=
				new DataBaseBovini();
		dataBaseBovini.connessioneDB();
		
		Bovino bovinoDaInserire=
				new Bovino(LocalDate.of(2005, 2, 1), 890, "IT056990008297", "Maremmana", 'F');
		dataBaseBovini.inserisciBovino(bovinoDaInserire);
		dataBaseBovini.leggiDB();//chiude la connessione, non ho bisogno di usare ilmetodo chiudi connessione

	}
}
