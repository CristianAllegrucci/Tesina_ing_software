package Controller;

import java.util.ArrayList;
import java.util.List;

import Model.Mezzo;

public class CalcolaMezziDisponibili {
	
	public List<Mezzo> calcolaMezziDisponibili(List<Mezzo>listaMezzi) {
		List<Mezzo>listaMezziDisponibili=new ArrayList<Mezzo>();
		
		for (Mezzo mezzo : listaMezzi) {
			if(mezzo.isDisponibile()) {
				listaMezziDisponibili.add(mezzo);
			}
		}
		return listaMezziDisponibili;
	}
	

}
