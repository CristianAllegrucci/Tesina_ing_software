import java.time.LocalDate;

public abstract class Bestiame {

	private int matricola;

	private String razza;
	private String sesso; 

	private LocalDate nascita;

	protected double peso;
	
	// private double prezzoKG;

	public Bestiame(int matricola, String razza, String sesso, LocalDate nascita) {
		this.matricola = matricola;
		this.razza = razza;
		this.sesso = sesso;
		this.nascita = nascita;
	}

	public int getMatricola() {
		return matricola;
	}

	public String getRazza() {
		return razza;
	}

	public String getSesso() {
		return sesso;
	}

	public LocalDate getNascita() {
		return nascita;
	}

	public double getPeso()
	{
		return peso;
	}

}

// da questa posso partire per creare tutte le classi che fanno riferimento alla tipologia bestiame

