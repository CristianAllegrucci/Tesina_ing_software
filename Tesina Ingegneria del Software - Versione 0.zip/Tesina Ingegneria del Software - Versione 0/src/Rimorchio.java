import java.time.LocalDate;

public class Rimorchio extends Mezzo{

	public Rimorchio(String marca, String modello, String targa, double consumo, LocalDate immatricolazione,
			LocalDate prossimaRevisione, LocalDate dataAcquisto) {
		super(marca, modello, targa, consumo, immatricolazione, prossimaRevisione, dataAcquisto);
		this.mezzoPrincipale = mezzoPrincipale;
		// TODO Auto-generated constructor stub
	}


	private Mezzo mezzoPrincipale;


	public void cambiaPrincipale(Mezzo nuovoPrincipale)
	{
		mezzoPrincipale= nuovoPrincipale;
	}
}
