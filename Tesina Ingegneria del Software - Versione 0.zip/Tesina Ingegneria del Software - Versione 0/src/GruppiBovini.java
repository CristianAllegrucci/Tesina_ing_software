import java.util.LinkedList;
import java.util.List;

// classe astratta comune sia a mandria che a stalla

public abstract class GruppiBovini {

	private String codice; 
	
	private List<Bovino> listaBovini;
	
	public void GruppiBovini(String codice) {
		this.codice = codice;
		this.listaBovini = new LinkedList<>(); // oppure arraylist
		// ipotizzio che nel momento in cui creo una mandria/stalla, questa sia vuota
	}
	
	// stalla e mandria sono oggetti dinamici, i bovini vengono aggiunti e rimossi ripetutamente durante 
	// il corso dell'anno
	
	public String getCodice() {
		return codice;
	}
	
	public List<Bovino> getListaBovini()
	{
		return listaBovini;
	}

	public void aggiungiBovino(Bovino bovino)
	{
		listaBovini.add(bovino);
	}
	
	public void rimuoviBovino(Bovino bovino)
	{
		/*
		 *  Ricerca del bovino nella lista per mezzo dell'identificativo
		 */
		int index = 0;
		
		listaBovini.remove(index);
		
	}
}
