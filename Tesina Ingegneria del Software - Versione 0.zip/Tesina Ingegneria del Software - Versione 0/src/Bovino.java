import java.time.LocalDate;
import java.util.Date;

public class Bovino extends Bestiame{

	private int prezzoKG;

	public Bovino(int matricola, String razza, String sesso, LocalDate nascita) {
		super(matricola, razza, sesso, nascita);
	}
	
}
