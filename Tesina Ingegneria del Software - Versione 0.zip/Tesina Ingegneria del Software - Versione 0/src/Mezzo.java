import java.time.LocalDate;

public class Mezzo {
	
	private String marca;
	private String modello;
	
	private String targa;	// nel formato LLnnnLL es. AA000AA - va inserito un controllo sulla validit�
	
	private double consumo;
	
	private LocalDate immatricolazione;
	private LocalDate prossimaRevisione;
	
	private LocalDate dataAcquisto;
	private LocalDate dataVendita=null; // si pu� usare per vendita o dismissione/rottamazione
		
	public Mezzo(String marca, String modello, String targa, double consumo, LocalDate immatricolazione,
			LocalDate prossimaRevisione, LocalDate dataAcquisto) {
		// super();
		this.marca = marca;
		this.modello = modello;
		this.targa = targa;
		this.consumo = consumo;
		this.immatricolazione = immatricolazione;
		this.prossimaRevisione = prossimaRevisione;
		this.dataAcquisto=dataAcquisto;
	}
	
	public LocalDate getDataVendita() {
		return dataVendita;
		// restituisce null se non � ancora stato venduto 
	}

	public void setDataVendita(LocalDate dataVendita) {
		this.dataVendita = dataVendita;
	}

	public LocalDate getDataAcquisto() {
		return dataAcquisto;
	}

	public LocalDate getProssimaRevisione() {
		return prossimaRevisione;
	}

	public void setProssimaRevisione(LocalDate prossimaRevisione) {
		this.prossimaRevisione = prossimaRevisione;
	}

	public String getMarca() {
		return marca;
	}

	public String getModello() {
		return modello;
	}

	public String getTarga() {
		return targa;
	}

	public double getConsumo() {
		return consumo;
	}

	public LocalDate getImmatricolazione() {
		return immatricolazione;
	}
	
	
}
