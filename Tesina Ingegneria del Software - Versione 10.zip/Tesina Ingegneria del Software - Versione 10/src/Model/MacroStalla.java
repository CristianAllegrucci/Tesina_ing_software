package Model;

import java.util.ArrayList;
import java.util.List;

public class MacroStalla implements NodoStalla {

	private List<NodoStalla>listaNodiStalla=
			new ArrayList<NodoStalla>();
	
	public void aggiungiStalla(Stalla stalla) {
		listaNodiStalla.add(stalla);
	}
	
	@Override
	public int calcolaNumBovini() {
		int totale=0;
		for (NodoStalla nodoStalla : listaNodiStalla) {
			totale+=nodoStalla.calcolaNumBovini();
		}
		return totale;
	}

	@Override
	public List<Bovino> getBovini() {
		List<Bovino>listaBase=new ArrayList<>();
		for (NodoStalla nodoStalla : listaNodiStalla) {
			listaBase.addAll(nodoStalla.getBovini());
		}
		return listaBase;
	}
	
}
