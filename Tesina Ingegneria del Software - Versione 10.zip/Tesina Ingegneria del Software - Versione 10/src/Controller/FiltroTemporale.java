package Controller;
import java.util.List;

import Model.Pagamento;

public interface FiltroTemporale<T> {
	
	public  List<T> filtraTemporalmente(List<T>	lista);

}
