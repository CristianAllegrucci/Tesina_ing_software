package View;
import Controller.OperazioneSuPagamentoSuPeriodoTemporale;
import Model.Azienda;
import Model.Bovino;
import Model.Dipendente;
import Model.Pagamento;

public class GestoreAzienda {

	private Azienda azienda;

	public GestoreAzienda(Azienda azienda) {
		this.azienda = azienda;
	}

	// gestione dipendenti
	public void AggiungiDidendente(Dipendente dipendente) {
		azienda.getListaDipendente().add(dipendente);
	}

	// ho eliminato il parametro di input Dipendente dipendente
	// perche non utilizzato
	public void RimuoviDidendente() {
		if (azienda.getListaDipendente().size() == 0) {
			System.out.println("Lista dipendenti vuota, impossibile rimuovere");
		} else {
			int i = 0;
			azienda.getListaDipendente().remove(i);
		}

	}

	// gestione bovini
	public void AggiungiBovino(Bovino bovino) {
		azienda.getListaBovini().add(bovino);
	}

	// stessa cosa, ho eliminato bovino come parametro di input
	public void RimuoviBovino() {
		if (azienda.getListaBovini().size() == 0) {
			System.out.println("Lista bovini vuota, impossibile rimuovere");
		} else {
			int i = 0;
			azienda.getListaBovini().remove(i);
		}
	}

	// fattura
	public void AggiungiFattura(Pagamento pagamento) {
		azienda.getListaFatture().add(pagamento);
	}

	/*metodo per richiamare lo strategy sulle operazioni di pagamento.
	 sul main mi preoccupero di passare il filtro e il tipo di costo da
	 calcolare*/
	public double calcolaPagamentoSuPeriodo(OperazioneSuPagamentoSuPeriodoTemporale op) {
		return op.calcolaSuPeriodo(azienda.getListaFatture());
	}
}
