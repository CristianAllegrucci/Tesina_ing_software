package Controller;
import java.util.List;

import Model.Pagamento;

public interface FiltroTemporale {
	
	public List<Pagamento> filtraTemporalmente(List<Pagamento>	listaPagamenti);

}
