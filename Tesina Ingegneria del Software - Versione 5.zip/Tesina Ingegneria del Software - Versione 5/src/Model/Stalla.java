package Model;
import java.util.ArrayList;
import java.util.List;

// versione 2 di stalla.java che estende la classe gruppi
// evito duplicazione del codice

public class Stalla extends Gruppo{
	
	public Stalla(String codice, List<Bovino> listaBovini,
			List<Edificio> listaEdificiPerStalla) {
		super(codice, listaBovini);
		this.listaEdificiPerStalla=listaEdificiPerStalla;
	}
	private List<Edificio> listaEdificiPerStalla=
			new ArrayList<Edificio>();
	
	
	
	
	
	// da creare classe in cui definire gli stabili 
	//che possono essere utilizzati
	// e classificarli in base alla capienza e alla dimensione

	// si pu� mettere quanto segue con un interfaccia 
}
