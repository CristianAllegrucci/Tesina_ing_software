package Model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Spesa extends Pagamento {
	
	public Spesa(LocalDate dataFattura, double costo, Object object) {
		super(dataFattura, costo);
		aggiungiOggetto(object);
	}

	public void aggiungiOggetto(Object object) {
		listaSpese.add(object);
	}
	
	private List<Object>listaSpese=
			new ArrayList<Object>();
	
	
/*	public double Costo(List<Pagamento> l)
	{
		double tot=0;
		for (Pagamento pagamento : l) {
			
			if (pagamento.getTipologia()=="Acquisto")
			{
				tot+=pagamento.getPrezzo();
			}
		}
		return tot;
	}*/

}
