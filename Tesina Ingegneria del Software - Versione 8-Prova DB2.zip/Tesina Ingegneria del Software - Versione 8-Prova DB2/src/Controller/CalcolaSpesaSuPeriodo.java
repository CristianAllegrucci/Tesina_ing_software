package Controller;
import Model.Pagamento;
import Model.Spesa;

public class CalcolaSpesaSuPeriodo extends CalcolaPagamentoSuPeriodo {

	public CalcolaSpesaSuPeriodo(FiltroTemporale filtroTemporale) {
		super(filtroTemporale);
	}

	@Override
	protected boolean verificaTipologiaSpesa(Pagamento pagamento) {		
		if(pagamento instanceof Spesa) { 
			return true;
		}
		return false;
	}
}
