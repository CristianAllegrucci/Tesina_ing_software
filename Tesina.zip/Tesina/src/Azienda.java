import java.util.List;

public class Azienda {
	
	// Dati dell'azienda
	private String nome;
	private String citta;
	private String indirizzo;
	private String telefono; // no int perch� potrebbe ignorare eventuali 0 iniziali 0039-075.... -> 39-....
	private String partitaIva;

	// Risorse
	private List<Dipendente> listaDipendente;
	private List<Bovino> listaBovini;
	
	// Costruttore
	public Azienda(String nome, String citta, String indirizzo, String telefono, String partitaIva) {
		super();
		this.nome = nome;
		this.citta = citta;
		this.indirizzo = indirizzo;
		this.telefono = telefono;
		this.partitaIva = partitaIva;
	}

	public String getNome() {
		return nome;
	}

	public String getCitta() {
		return citta;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public String getTelefono() {
		return telefono;
	}

	public String getPartitaIva() {
		return partitaIva;
	}

	
}
