import java.time.LocalDate;

public class Bovino {

	private LocalDate dataDiNascita;
	private double peso;
	private String matricola;
	private String razza;
	private String sesso;
	
	public Bovino(LocalDate dataDiNascita, double peso, String matricola, String razza, String sesso) {
		super();
		this.dataDiNascita = dataDiNascita;
		this.peso = peso;
		this.matricola = matricola;
		this.razza = razza;
		this.sesso = sesso;
	}
	
	public LocalDate getDataDiNascita() {
		return dataDiNascita;
	}

	public double getPeso() {
		return peso;
	}

	public String getMatricola() {
		return matricola;
	}

	public String getRazza() {
		return razza;
	}

	public String getSesso() {
		return sesso;
	}

	public String ClassificaBovino() {
		
		if(dataDiNascita.isBefore(LocalDate.now().plusYears(-1)))
			return "Vitello";
		else
			return "Bovino";
		
	}
			
		
}


